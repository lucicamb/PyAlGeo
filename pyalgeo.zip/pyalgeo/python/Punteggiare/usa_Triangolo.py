# File: usa_Triangolo.py - ok
# Date: 8 feb 23
# Note: programma che usa la classe Triangolo

... DA COMPLETARE



#---- main ----
A = Point((1,1),name='A',color='grey',state=DRAGABLE)
B = Point((4,2),name='B',color='grey',state=DRAGABLE)
C = Point((2,4),name='C',color='grey',state=DRAGABLE)

