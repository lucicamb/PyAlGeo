# File: prova_mucchi.py
# Date: 19 set 21
# Note: prove di operazioni sui mucchi

O = ()
a = ()
a1 = O  
b = (1)
c = (3)
d = b+c
print("mucchio a =",a) # ()
print("mucchio a1 =",a1) # ()
print("mucchio b =",b) # 1
print("mucchio c =",c) # 3
print("mucchio d =",d) # 4

