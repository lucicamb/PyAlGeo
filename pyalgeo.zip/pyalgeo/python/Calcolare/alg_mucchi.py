# File: alg_mucchi.py
# Date: 19 set 21
# Note: algoritmi sui mucchi

from Mucchio import *

#---------------------------------------------
# funzioni basate sul kernel del modulo mucchi importato sopra

# inserimento di n elementi nel mucchio
def inserisci(m:Mucchio,n:int):
    for _ in range(n):
        insert(m)

def svuota(m:Mucchio):
    while not isempty(m):
        delete(m)

# sposta un elemento da A a B 
def sposta(A:Mucchio,B:Mucchio):
    if not isempty(A):
        delete(A)
        insert(B)

def svuota(m:Mucchio):
    while not isempty(m):
        delete(m)

        
#-----------------------------------
if __name__ == '__main__':

    '''
    # prove su riferimenti e copie
    a = Mucchio()
    b = a
    insert(a)
    insert(b)
    print('a =',a)
    print('b =',b)
    c = copy(a)
    inserisci(a,10)
    delete(b)
    print('a =',a)
    print('b =',b)
    print('c =',c)
    svuota(a)
    print('a =',a)
    print('b =',b)
    print('c =',c)
    '''

    # operazioni varie
    a = Mucchio(1)
    b = Mucchio(4)
    c = clone(b)
    print('a =',a)
    print('b =',b)
    sposta(a,b)
    sposta(a,b)
    print('a =',a)
    print('b =',b)
    print('c =',c)


    
