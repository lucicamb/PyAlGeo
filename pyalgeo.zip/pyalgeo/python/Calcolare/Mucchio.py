# File: Mucchio.py
# Date: 1 feb 23
# Note: operazioni sui mucchi - non e' iterabile

# When an instance method object is called, the underlying function
# (__func__) is called, inserting the class instance (__self__) in front
# of the argument list. For instance, when C is a class which contains a
# definition for a function f(), and x is an instance of C,
# calling x.f(1) is equivalent to calling C.f(x, 1).

from copy import *
from time import sleep

class Mucchio:
#class Mucchio(KObject): 

    # mucchio vuoto o di n elementi
    def __init__(self,n=0):
        self._num = n
        self._idx = 0 #indice dell'iteratore
        self._prefix = '' #prefisso nelle write
        #self._children = [] #per poter fare le write
        self._strvar = StringVar()
        self._update()

    # inserimento di un elemento
    def insert(self):
        self._num += 1 
        self._update()

    # rimozione di un elemento
    def remove(self):
        if self._num>0:
            self._num -= 1
            esito = True
        else:
            esito = False
        self._update()
        return esito

    # test se il mucchio e' vuoto
    def isempty(self) -> bool:
        return self._num==0

    # copia di un mucchio 
    def clone(self) -> bool:
        return self._num==0
        
    # esegue un set-refresh della StringVar sulla WinTxt
    def _update(self):
        #print('        ------ update di Mucchio ---------')
        self._strvar.set(self.tostring()) # non basta per il refresh; serve la [*]
        refreshwintxt()                   # forza il refresh della finestra testo [*]
        sleep(0.5)                        # attesa per vedere l'effetto
           
    # funzione di conversione in stringa
    #def __repr__(self):
    def __str__(self):
        s = '('+str(self._num)+')'
        return s

    # un mucchio viene reso iterabile: MA E' GIUSTO ???
    def __iter__(self):
        #return self   #ok
        return copy(self)

    def __next__(self):
        if self._idx >= self._num: 
            raise StopIteration
        else:
            self._idx += 1
            return 'o' 

    '''
    # stringa dinamica dell'oggetto;
    # ritorna il Value corrispondente alla stringa dinamica dell'oggetto convertito in stringa
    def stringval(self,prefix=None):
        #if prefix!=None: self._prefix = prefix # trucco per passarlo al metodo converti
        self._prefix = prefix if not prefix is None else '' # trucco per passarlo al metodo tostring
        return KValue(self,self.tostring,'MUCCHIO',StringVar())  
    '''

    # stringa attuale statica del punto
    def tostring(self):
        #print('-------------- Mucchio.py: in tostring --------------')
        #return '('+str(self._num)+')'
        #return self._prefix+'('+str(self._num)+')'
        return self._prefix+str(self)
    
    # stringa attuale statica del punto (senza prefisso)
    def __str__(self):
        #print('-------------- Mucchio.py: in tostring --------------')
        #return '('+str(self._num)+')'  #ok
        s = '['
        for _ in range(self._num): s+='*'
        return s+']'
        
        
    
    # quanto segue serve solo per la finestra separata delle label [+24giu19]
    def getstringvar(self,prefix=''):
        #s = self.stringval(prefix)
        #if not prefix is None: self._prefix = prefix
        self._prefix = prefix  #2feb23
        return self._strvar
        
#---- funzioni in modalita' procedurale ----
    
# inserimento di un elemento
def insert(m:Mucchio):  
    m.insert() 

# eliminazione di un elemento
def remove(m:Mucchio):
    m.remove()

# test se il mucchio e' vuoto
def isempty(m:Mucchio) -> bool:
    return m.isempty()    

# copia di un mucchio 
def clone(m:Mucchio) -> Mucchio:
    return copy(m) 


#-----------------------------------
#if __name__ == '__main__':

    ''' prove base
    m = Mucchio()
    print('m =',m)
    print('m isempty =',m.isempty())
    m.insert()
    print('m =',m)
    for _ in range(8):
        m.insert()
    print('m =',m)
    print('m isempty =',m.isempty())
    for _ in range(6):
        m.delete()
    print('m =',m)
    for _ in range(6):
        m.delete()
    print('m =',m)
    insert(m)
    #inserisci(m)
    print('m =',m)
    '''

    '''
    # prove sui possibili modi di chiamata
    m = Mucchio()
    Mucchio.insert(m) #equivalente a m.insert()
    print('m =',m)
    print('m.isempty() =',m.isempty())
    print('Mucchio.vuoto(m) =',Mucchio.vuoto(m))
    print('isempty(m) =',isempty(m))
    '''


    '''
    # prove su riferimenti e copie
    a = Mucchio()
    b = a
    insert(a)
    insert(b)
    print('a =',a)
    print('b =',b)
    c = copy(a)
    remove(b)
    print('a =',a)
    print('b =',b)
    print('c =',c)

    for _ in range(2): insert(a)

    #test su mucchi iterabili
    for x in a:
        for y in a:
            print(x)
    '''

#prove per PyAlgoGeo - ok
A = Mucchio(10)
B = Mucchio()
scrivi('A='+str(A))
scrivi('B='+str(B))
write('A=',A)
write('B=',B)

#'''
print('passata parte iniziale in Mucchio.py')
sleep(2) 
while not isempty(A):
    remove(A)
    insert(B)
#'''


    




    




