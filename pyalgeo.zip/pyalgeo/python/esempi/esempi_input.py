# File: esempi_input.py
# Date: 13 feb 23
# Note: modulo di funzioni sulle circonferenze

from costruzioni import *  

#LE FUNZIONI CHE SEGUONO SONO GIA' PREDISPOSTE DAI COSTRUTTORI (CON INPUT)

# input di una circonferenza con raggio fisso;
# in input viene selezionato solo il centro;
# ritorna il Circle acquisito in input;
# vengono impostati gli attributi attuali (colore, stato, ...)
def input_circlerag(rag:float) -> Circle :
    C = Point(INPUT,state=DRAGABLE) #.config(name='Q',color='green')
    a = Circle(C,rag) #,color='red',state=DRAGABLE)
    return a

# input di una circonferenza con centro fisso (rubberband);
# in input viene selezionato solo il punto periferico;
# ritorna il Circle acquisito in input;
# vengono impostati gli attributi attuali (colore, stato, ...)
def input_circlecen(C:Point) -> Circle :
    a = Circle(INPUT,node=C) 
    return a

# input di una circonferenza con selezione di 3 punti (rubberband);
# ritorna il Circle acquisito in input;
def input_circle3p() -> Circle :
    a = Circle(INPUT,node=())  # per 3 punti
    return a
    

#---- main ----

#''' 
#-- input di Line -- ok 13feb23
Tipo = Line #Segment
P = Point(2,3).config(color='blue',state=DRAGABLE) 
Q = Point(-1,1).config(color='blue',state=DRAGABLE)
c = Circle(Point(1,2,color='green',state=DRAGABLE),2.5,state=DRAGABLE,color='red') #rosso solo sensibile
l0 = Tipo(P,Q,color='orange',state=DRAGABLE)
l1 = Tipo(P,(2,5),color='red',state=DRAGABLE)
#l2 = Tipo(INPUT,color='green',state=DRAGABLE)
l2 = Tipo(INPUT,state=DRAGABLE)  #permette il cambio di colore
l3 = Tipo(INPUT,Q,color='brown',state=DRAGABLE)
l4 = Tipo(INPUT,(4,1),color='blue',state=DRAGABLE,on=c)
#'''


''' 
#-- input di Circle -- ok 13feb23
P = Point(2,3).config(color='blue',state=DRAGABLE) 
Q = Point(1,4).config(color='blue',state=DRAGABLE)
R = Point(0,2).config(color='blue',state=DRAGABLE)
c = Circle(Point(1,2,color='orange',state=DRAGABLE),2.5,state=DRAGABLE,color='red')
c0 = Circle((P,Q,R),color='red',state=DRAGABLE)
c1 = Circle(INPUT)            #circle con input di centro e punto di passaggio
#
#c2 = Circle(INPUT,2)          #circle con input di centro e raggio costante
c2 = Circle(INPUT,2,color='brown',on=c)          #circle con input di centro e raggio costante
c3 = Circle(INPUT,radius(c1)) #circle con input di centro e raggio variabile
c4 = Circle(INPUT,P)          #circle di centro P
c5 = Circle(INPUT,())         #circle passante per 3 punti di input
c6 = Circle(INPUT,(P,))       #circle passante per P
c7 = Circle(INPUT,(P,Q))      #circle passante per P e Q
show('raggio=',radius(c1))
show('centro=',center(c1))
'''


''' 
#prova 2: ok 8mag22
message('input di 3 punti...')
P1 = Point(INPUT)
P2 = Point(INPUT)
P3 = Point(INPUT)
message('')
c = Circle((P1,P2,P3)) #gestire anche senza doppia parentesi...
#c = Circle((P1,P2,P3)).config(color='red')
'''


