# File: test_point.py - ok
# Date: 25 gen 23
# Note: operazioni varie sui punti

grid()

''' 
#---- test sul calcolo dell'omotetico ---- ok
A = Point(INPUT,name='A',msg='input punto...',color='red',state=DRAGABLE)
B = Point(INPUT,name='B',msg='input punto...',color='red',state=DRAGABLE)
P = Point(INPUT,name='P',msg='input punto...',color='blue',state=DRAGABLE)
Q = Point(INPUT,name='Q',msg='input punto...',color='blue',state=DRAGABLE)
#r = dist(A,O)/dist(B,O)  #ok
r = dist(P,O)/dist(Q,O)
write('r=',r)
s = Segment(A,B,color='orange',state=VISIBLE)
K = hom(A,B,r).config(name='K',color='red',state=VISIBLE)
#L = hom(A,B,0.66).config(name='K',color='blue',state=VISIBLE)
'''

'''
#---- test con le assegnazioni e clone dei punti ---- ok
A = Point(INPUT,name='A',msg='input punto...',color='red',state=DRAGABLE)
B = Point(INPUT,name='B',msg='input punto...',color='green',state=DRAGABLE)
write('dist1(A,B)=',dist(A,B))
T = A   #T e' un alias di A
T.config(name='T',color='orange')
write('dist2(T,B)=',dist(T,B))

#B = A        #B e' un alias di A
#B = Point(A) #B e' un clone autonomo da A
B = Point(T)  #B e' clone autonomo (il vecchio B rimane zombi attivo) 

B.config(state=DRAGABLE,name='B',color='blue')  
write('dist3(A,B)=',dist(A,B))
'''


'''
#---- test sui riferimenti e copie ----
A = Point((2,3),name='A',color='blue',state=DRAGABLE) #VISIBLE o DRAGABLE
X = A
X.config(color='red')
write('X=',X)
#Y = Point(A)  # costruttore per copia: ok
#Y = Point(X)  # costruttore per copia: ok, come sopra
#Y = clone(X)  # ok
Y = clone(A)   # ok
#write('Y=',Y)
write(Y.getname(),Y)
Y.config(color='blue')
'''


'''
#---- operazioni di confronto sui punti - ok 23gen23
A = Point((2,3),name='A',color='red',state=DRAGABLE)  
B = Point((3,2),name='B',color='brown',state=DRAGABLE)
T = A
#B = Point(INPUT,name='B',msg='input punto...',color='brown',state=DRAGABLE)
write('A==B = ',A==B)
write('A!=B = ',A!=B)
write('A is B = ',A is B)
write('B is A = ',B is A)
write('T is A = ',T is A)
write('A is T = ',A is T)
'''


#'''
#---- coordinate e distanze - .. 23gen23
A = Point((2,3),name='A',color='red',state=DRAGABLE)  
B = Point((3,2),name='B',color='brown',state=DRAGABLE)
#xA = coordx(A)  #ok
#yA = coordy(A)
xA, yA = coords(A)
de = dist(A,B)
dm = distm(A,B)
write('xA = ',xA)
write('yA = ',yA)
write('dist euclidea = ',de)
write('dist Manhattan= ',dm)




'''
C = hom(A,B,1.2).config(name='hom(A,B,1.2)',state=DRAGABLE,color='blue')
D = rot(A,B,30).config(name='rot(A,B,30)',state=DRAGABLE,color='blue')
E = med(A,B).config(name='med(A,B)',state=DRAGABLE,color='orange')
F = sym(A,B).config(name='sym(A,B)',state=DRAGABLE,color='blue')
G = (A+B).config(name='A+B',state=DRAGABLE,color='red')
H = (A-B).config(name='A-B',state=DRAGABLE,color='red')
K = (2*A).config(name='2*A',state=DRAGABLE,color='red')
L = (-A).config(name='-A',state=DRAGABLE,color='red')
write('dist(C,D)=',dist(C,D))

xA = coordx(A)
yA = coordy(A)
write('x(A)=',xA)
write('y(A)=',yA)
x, y = coords(A)
write('x=',x)
write('y=',y)

X = (4*U).config(name='4*U',state=DRAGABLE,color='black')  
Y = (A+4*U).config(name='A+4*U',state=DRAGABLE,color='black') 

s = Segment(A,B,color='red',state=VISIBLE)
r = Line(X,Y,color='red',state=VISIBLE)
g = Circle(Y,dist(C,D),name='g',color='red',state=DRAGABLE)
P = Point(INPUT,msg='punto su g ...',on=g,name='P',color='red',state=DRAGABLE)
write('s=',s)
write('r=',r)
write('g=',g)
write('P=',P)

#punti casuali:
for _ in range(10):
    Point(RANDOM,on=g,color='green',state=VISIBLE)
for _ in range(10):
    Point(RANDOM,on=s,color='orange',state=VISIBLE)   
for _ in range(10):
    Point(RANDOM,on=r,color='brown',state=VISIBLE)       
'''


'''
#---- test vari ----
B = Point(INPUT,name='B',msg='input punto...',color='red',state=DRAGABLE)
s = Segment(A,B,color='orange',state=VISIBLE)
C = Point(INPUT,name='C',msg='input punto su segmento...',on=s,color='red',state=DRAGABLE)
d = dist(A,B)
#c = Circle(A,d/2,color='blue',state=DRAGABLE)      # (1) ok
#c = Circle(A,med(A,B),color='blue',state=DRAGABLE) # (2) equivale a (1) (ma piu' veloce)
#c = Circle(A,B,color='blue',state=DRAGABLE)        # (3) quasi come (1)
c = Circle(A,2.5,color='blue',state=DRAGABLE)       # (4) circle mobile ma di raggio costante

Text((3,-3),"distanza = {0}",d, color='red')
D = Point(INPUT,name='D',msg='input punto su circle...',on=c,color='red',state=DRAGABLE)
E = Point(RANDOM,name='E',on=c,color='green',state=DRAGABLE)
'''


