# File: testi.py 
# Date: 22 feb 23
# Note: visualizzazione testi sulla finestra grafica 
#       e sulla finestra delle label
#
#       NOTA: print('{0} {1} cost ${2}'.format(6, 'bananas', 1.74)) produce "6 bananas cost $1.74"

#from Poligono import *  

#---- testi ---- ok 22feb23
Text((5,6),"Testo visibile non dragabile",color='blue',state=VISIBLE)
Text((5,5.5),"Testo dragabile rosso",color='green',state=DRAGABLE).config(color='red')
Text((5,5),"TESTO parametrico costante = {0}",123.45, color='brown').config(state=DRAGABLE)
P = Point(5,4.5,color='brown',state=DRAGABLE)
t = Text(P,"testo in P dragabile con XP={0}",coordx(P),color='orange').config(state=DRAGABLE)
Text(Point(5,4),'P:[{0},{1}]',[coordx(P),coordy(P)],color='orange',state=DRAGABLE)

Text((-5,4),"Centrato su (5,4)",color='brown',state=VISIBLE,anchor=CENTER)
Text((-5,3),"Nord di (5,3)",color='brown',state=VISIBLE,anchor=NORTH)
Text((-5,2),"NordEst di (5,2)",color='brown',state=VISIBLE,anchor=NORTHEAST)
Text((-5,1),"Est di (5,1)",color='brown',state=VISIBLE,anchor=EAST)
Text((-5,0),"SudEst di (5,0)",color='brown',state=VISIBLE,anchor=SOUTHEAST)
Text((-5,-1),"Sud di (5,-1)",color='brown',state=VISIBLE,anchor=SOUTH)
Text((-5,-2),"SudWest di (5,-2)",color='brown',state=VISIBLE,anchor=SOUTHWEST)
Text((-5,-3),"West di (5,-3)",color='brown',state=VISIBLE,anchor=WEST)
Text((-5,-4),"NordWest di (5,-4)",color='brown',state=VISIBLE,anchor=NORTHWEST)

#Writing((3,6),"Testo visibile non dragabile",color='blue',state=VISIBLE)


'''
#---- nomi di oggetti ----
# il nome deve essere una stringa; crea automaticamente la label
A = Point(INPUT,name='A',msg='seleziona punto A...',color='green',state=DRAGABLE) 
B = Point(INPUT,msg='seleziona punto...',color='blue',state=DRAGABLE) 
#C = (A+B).config(state=VISIBLE,color='red',name='A+B')  #ok: label non dragabile
#C = (A+B).config(state=DRAGABLE,color='red',name='A+B',offset=(20,0))  #da gestire
C = (A+B).config(state=DRAGABLE,color='red',name='A+B')  #ok:label dragabile  
#C = (A+B).config(state=VISIBLE,color='red',name=coordx(A))  #ERRORE 
#C = (A+B).config(state=DRAGABLE,color='red',name=str(coordx(A)))  #ok (label statica)
Poligono([A,O,B,C],color='red',state=DRAGABLE,width=MEDIUM)
c = Circle(C,2,color='blue',state=VISIBLE,width=THIN)

#---- label ----
#creare label su punto equivale (quasi) a creare punto con nome (a parte i colori)
Point(1,1,name='PUNTO(1,1)',color='red',state=DRAGABLE)  
Label(Point(2,2,color='red',state=DRAGABLE),"LABEL(2,2)",color='brown',state=DRAGABLE)   
Label(B,"B=[{0},{1}]",[coordx(B),coordy(B)],color='brown').config(state=DRAGABLE) 

#---- write sulla finestra a parte ----
write('A=',A)
write('B=',B)
write('XA=',coordx(A))
k = coordx(A)<coordy(A)
write('k=',k)
write('dist(A,B)=',dist(A,B))
'''


#---- writing ----
#creare label su punto equivale (quasi) a creare punto con nome (a parte i colori)
#Point(1,1,name='PUNTO(1,1)',color='red',state=DRAGABLE)  
#Writing(Point(3,-2),"WRITING(3,-2)",color='brown',state=DRAGABLE)   
#Label(B,"B=[{0},{1}]",[coordx(B),coordy(B)],color='brown').config(state=DRAGABLE) 

Writing((80,30),"WRITING costante e dragabile",color='brown',state=DRAGABLE) 
Writing((80,50),"WRITING costante non dragabile",color='red',state=VISIBLE)     
Writing((80,70),"P=[{0},{1}]",variables=[coordx(P),coordy(P)],state=DRAGABLE)  


'''
write('-------------- testi con la t. -------')
d1 = dist(A)               
write('dist(tarta,A)=',d1)   #dinamica in A
d2 = dist(A,pos())
write('dist(A,pos())=',d2)   #dinamica in A e tarta
T = pos()
T.config(name='C',color='red',state=DRAGABLE)
d3 = dist(T,C)               #dinamica in B
write('dist(B,C)=',d3) 
x, y = getpos()  #definita in kinter
a = angle()
V = Point((y,x),name='V',color='orange',state=const.DRAGABLE)
write('posizione X attuale della t.=',x) 
write('posizione Y attuale della t.=',y)
#show()  #dell t. 
write('---------------------')
'''





 
