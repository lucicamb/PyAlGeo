# File: test_intersezioni.py - ok
# Date: 13 dic 22 
# Note: intersezioni fra entità' grafiche

'''
from kinter import *   #?perche' adesso chi include costruzioni ha gia' incl. kinter

# specifica del percorso di importazioni moduli utente - ok [24lug21]
import sys
sys.path.append('..\python')

from costruzioni import * #prova del 17lug21 (ok, ma costruzioni deve essere locale)
'''

grid()

'''
#-- prova mista --
A = Point((2,3),color='red',state=DRAGABLE)
a = Circle(A,2,color='blue',state=DRAGABLE)
B = Point((1,2),color='red',state=DRAGABLE)
b = Circle(B,2,color='blue',state=DRAGABLE)

#ax = kasse(A,B) #kasse e' in kinter
#ax = asse(A,B)   #asse e' in ..\python\costruzioni
#ax.config(color='red',state=VISIBLE)

P, Q = inters(a,b)  #non si vedono
P.config(state=SENSIBLE,color='red')
Q.config(state=SENSIBLE,color='red')
s = Segment(P,Q,color='green',state=SENSIBLE)
'''

#-- intersezione retta-circ --
A = Point((1,3),color='blue',state=DRAGABLE)
#B = Point((4,2),color='blue',state=DRAGABLE)
B = Point((1,3),color='blue',state=DRAGABLE) #coincidente con A - caso limite
r = Line(A,B,color='red',state=DRAGABLE,width=MEDIUM)
C = Point((3.5,2),color='blue',state=DRAGABLE)
c = Circle(C,2,color='blue',state=DRAGABLE)
P, Q = inters(r,c)  #non si vedono
P.config(name='P',color='red',state=DRAGABLE)
Q.config(name='Q',color='red',state=DRAGABLE)



