# File: test_pen.py - ..
# Date: 13 dic 22
# Note: esempi sul disegno mediante una penna (classe Pen)

#import dygeo  #file .zip


#-- prova base -- ok 13dic22

write('scala=',scale())

penred = Pen(color='red',width=3)
'''
P = penred.pos()
D = penred.dpos()
write('P=',P)
write('D=',D)
'''
#penred._place(plane)
#pen.drawcircle(5,(2,3),color='red',width=2,incolor='white')

#penred.drawsegment((4,1),(7,-3))

penred.move((1,1))
penred.draw((2,1))
P = penred.here()
D = penred.pos()
write('P=',P)
write('D=',D)
penred.draw((2,2))
penred.draw((1,2))
penred.draw((3,3))

#x, y = penred.coords()  #coppia di coordinate (numeriche, no DataObject)
#print('X finale =',x,'  Y finale =',y)





'''
    # prove nel caso sia la t. su un Point [-12mag22]
    xv = x.value()
    yv = y.value()
    print('COORDINATE DI PENNAROSSA: ',penred.coords())
    print('Xv=',xv,'  Yv=',yv)
    
    penred.move((1,1))
    penred.draw((2,2))

    xv = x.value()
    yv = y.value()
    #print('COORDINATE DI PENNAROSSA: ',penred.coords())
    print('Xv2=',xv,'  Yv2=',yv)
'''

'''    
    x, y = 2, 2
    for i in range(8):
        x += 1
        penred.draw((x,y))
        y += 1
        penred.draw((x,y))
    penblack.drawcircle(2)

    p = penred.pos()
    print('---- pen:main: p=',p)
'''
  
   

