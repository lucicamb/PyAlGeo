# File: esempi.py 
# Date: 21 apr 22
# Note: esempi da richiamare nel main dell'applicazione Dynamic Geometry
#       o provare direttamente alla fine, nel main di questo modulo

#from kinter import *
from costruzioni import *
#import graph #prova del 16nov19

from random import randint # per alcuni esempi

#===================================

# operazioni varie di intersezione e punti vincolati
# e visualizzazione sulla finestra testo dei dati
def esempio5():
    message('seleziona una circonferenza1 ...')
    c1 = Circle(INPUT,name='c1',color='orange',state=DRAGABLE)
    c2 = Circle(INPUT,name='c2',color='orange',state=DRAGABLE)
    write('circ c1 = ',c1)
    write('circ c2 = ',c2)
    message() #clear
    P1, P2 = inters(c1,c2)
    M = ((P1+P2)/2).config(width=3,color='blue',state=SENSIBLE)
    write('punto P1 = ',P1)
    write('punto P2 = ',P2)
    write('punto M = ',M)
    s = Segment(P1,P2).config(width=1,color='red',state=SENSIBLE)
    #r = Line(P1,P2,color='blue',state=SENSIBLE)
    message('seleziona punto su c1') 
    P = Point(INPUT,on=c1,color='red',state=DRAGABLE)
    message('seleziona punto su c2') 
    Q = Point(INPUT,on=c2,color='red',state=DRAGABLE)
    message() #clear
    s1 = Segment(P,P1).config(width=1,color='blue',state=VISIBLE)
    s2 = Segment(Q,P2).config(width=1,color='red',state=SENSIBLE)
           

# esempio sui punti vincolati - ex esempio 30 - da completare [10nov19]
def esempio7():
    message('seleziona un punto ...')
    A = read(const._POINT,color='blue',state=const.DRAGABLE)
    write('punto A = ',A)  
    d = dist(kinter.O,A)
    write('distanza = ',d)
    c = Circle(A,1.8*A).config(state=DRAGABLE,width=1,color='red')
    write('circonferenza c : ',c)

    '''
    K1 = ConstrainedPoint(c,0.3, color='red', width=3,name='K1',state=const.DRAGABLE) #ok
    K2 = ConstrainedPoint(c,0.7, color='red', width=3,name='K2',state=const.DRAGABLE)
    K3 = ConstrainedPoint(c,1.6, color='red', width=3,name='K3',state=const.DRAGABLE)
    K4 = ConstrainedPoint(c,2.8, color='red', width=3,name='K4',state=const.DRAGABLE)
    '''
    
    K1 = Point(PARAM,on=c,param=0.3, color='red', name='K1',state=INVISIBLE) 
    K2 = Point(PARAM,on=c,param=0.7, color='red', name='K2',state=VISIBLE) #RISULTA DRAGGABILE: SISTEMARE!![10nov19]
    K3 = Point(PARAM,on=c,param=1.0, color='red', name='K3',state=SENSIBLE) 
    K4 = Point(PARAM,on=c,param=2.8, color='red', name='K4',state=DRAGABLE) 
          
    write('K1 = ',K1)
    write('K2 = ',K2)
    write('K3 = ',K3)
    write('K4 = ',K4)
    write('distanza(K1K3) = ',dist(K1,K3))
     
    r = Line(K1,K3, width=1, color='orange', name='r')
    s = Line(K2,K4, width=1, color='orange', name='s')
    t = Segment(K1,K4, width=1, color='orange', name='t')
    
    #M = Intersection(r,s,name='M',width=3,color='red',state=const._VISIBLE) #ok-non agganciabile
    M = Intersection(r,s,name='M',width=3,color='red',state=const.SENSIBLE) #ok-cosi' e' agganciabile e condiviso
    write('M intersezione = ',M)
    write('retta s=K2K4 : ',s)
    write('segmento t=K1K4 : ',t)  
    write('k1 = ',K1)
    #T = ((M+K2)/2).config(color='red',trace='blue',state=const._VISIBLE) #per vedere tracing trascinando K2
    '''
         #P = 1.3*K1   #ok
         P = d*K1   #ok anche cosi'
         Q = hom(K1,K2,d/2)
         P.config(name='P',color='green',width=5,state=const.DRAGABLE)
         Q.config(name='Q',color='green',width=5,state=const.DRAGABLE)
         write('punto P : ',P) #scrittura sulla finestra testo
         write('punto Q : ',Q)
                
         rag = c.radius()
         cen = c.center()
         xc = cen.xcoord()
         yc = cen.ycoord()
         #cen.config(name='C',width=3,color='orange',visible=True)

         #---- diverse tipologie di testi ----
         VarText((-2, 0),'VarText non dinamico ma movibile',color='blue',state=const.DRAGABLE)      # non dinamico
         VarText((-2,-1), "distanza = {0}",d, color='red')                                           # variabile ma non movibile
         VarText((-2,-2),'Raggio = {0}',rag,state=const.DRAGABLE)                                   # variabile e movibile
         VarText((-2,-3),'Centro = ({0}; {1})',(xc,yc),color='blue',width=10,state=const.DRAGABLE)  # doppiamente variabile
         VarText(cen,'({0},{1})',(xc,yc),color='blue',width=10,state=const._VISIBLE)                 # variabile ed agganciato ad un punto (*)
         '''
         
         # quanto segue risente del zoom-in/out; SISTEMARE [28giu19]
         # possibile soluzione: fare un testo agganciato ad un punto (invisibile ?)
         #t4 = VarText(xc+1,yc,'({0},{1})',(xc,yc),color='blue',width=10) #si stacca in zoom

    ''' come segue e' ok, ma l'aggancio di un testo al punto e' meglio farlo come indicato nel caso (*) sopra
         # MIGLIORARE CON UN UNICO METODO QUANTO SEGUE: [1lug19]
         #t4 = VarText(xc,yc,'                        ({0},{1})',(xc,yc),color='blue',width=10,state=const.DRAGABLE) #ok 
         t4 = VarText((xc,yc),'                        ({0},{1})',(xc,yc),color='blue',width=10,state=const._VISIBLE) #ok 
         #cen.config(name=str(xc))  #no perche' xc rimane fisso
         cen.config(label=t4)  # riporta in primo piano il punto [1lug19]
    '''
        
    ''' adesso la classe Text non serve piu' (e' stata assorbita dalle funzionalita' di VarText)
         # prove per capire come funziona Text (la classe Text in graph.py entra in conflitto con il widget Text di tkinter)
         graph.Text((2,4),'Questo e un Text movibile',(),color='blue',width=10,state=const.DRAGABLE)
         graph.Text((2,3),'Questo e un Text fisso',(),color='red',width=10,state=const._VISIBLE)
         #Text((2,4),'Questo e un Text',(),color='blue',width=10,state=const.DRAGABLE) #conflitto con tkinter
    ''' 

# test sui punti INVISIBILI, VISIBILI, SENSIBILI, DRAGGABILI
def esempio8():
    A = Point(-2,-2).config(color='red',state=INVISIBLE)
    B = Point(2,-2).config(color='brown',state=VISIBLE)
    C = Point(2,2).config(color='blue',state=SENSIBLE)
    D = Point(-2,2).config(color='green',state=DRAGABLE)
    Segment(A,B, width=1, color='orange', name='s1')
    Segment(B,C, width=1, color='orange', name='s2')
    Segment(C,D, width=1, color='orange', name='s3')
    Segment(D,A, width=1, color='orange', name='s4')

    for i in range(40):
        x = 2.5 + (randint(0,19)) / 10
        y = 2.5 + (randint(0,19)) / 10
        Point(x,y,color='red',width=3,state=const.DRAGABLE)

    ''' SISTEMARE QUANTO SEGUE
    message('seleziona un punto ...')
    A = read(const._POINT,color='blue',state=const.DRAGABLE)
    write('punto A = ',A)  
    d = dist(kinter.O,A)
    write('distanza = ',d)
    c = Circle(A,1.8*A).config(state=DRAGABLE,width=1,color='red')
    write('circonferenza c : ',c)
      
    K1 = Point(PARAM,on=c,param=0.3, color='red', name='K1',state=INVISIBLE) 
    K2 = Point(PARAM,on=c,param=0.7, color='red', name='K2',state=VISIBLE) #RISULTA DRAGGABILE: SISTEMARE!![10nov19]
    K3 = Point(PARAM,on=c,param=1.0, color='red', name='K3',state=SENSIBLE) 
    K4 = Point(PARAM,on=c,param=2.8, color='red', name='K4',state=DRAGABLE) 
          
    write('K1 = ',K1)
    write('K2 = ',K2)
    write('K3 = ',K3)
    write('K4 = ',K4)
    write('distanza(K1K3) = ',dist(K1,K3))
     
    r = Line(K1,K3, width=1, color='orange', name='r')
    s = Line(K2,K4, width=1, color='orange', name='s')
    t = Segment(K1,K4, width=1, color='orange', name='t')
    '''

#---- intersezione circonferenza-semiretta ---- 19nov19
def esempio12():
    message('seleziona una semiretta ...')
    s = Ray(INPUT,name='s',color='orange',state=DRAGABLE)
    #A = head(s)
    #A.config(name='A',state=DRAGABLE,color='green')
    #B = tail(s)
    #B.config(name='B',state=DRAGABLE,color='green')
    message('seleziona una circonferenza2 ...')
    c = Circle(INPUT,name='c',color='blue',state=DRAGABLE)
    message('')
    A, B = inters(s,c)
    A.config(name='H',width=3,color='blue',state=VISIBLE)
    B.config(name='K',width=3,color='red',state=VISIBLE)

#---- struttura triangolo ---- 3giu21
def esempio13():
    message('seleziona punto ...')
    T = Point(INPUT).config(name='T',color='blue',state=DRAGABLE)
    #T.config(width=5)  #inibire questa possibilità
    message('seleziona segmento ...')
    #s = Segment(INPUT,node=T,name='s',color='orange',state=VISIBLE)
    s = Segment(INPUT,node=T).config(name='s',color='orange',state=VISIBLE)
    
    # input triangolo: metodo senza rubberband:
    message('seleziona 3 punti ...')
    A = Point(INPUT).config(name='A',color='blue',state=DRAGABLE)
    #B = Point(INPUT,on=A).config(name='B',color='blue',state=DRAGABLE)
    #C = Point(INPUT,on=B).config(name='C',color='blue',state=DRAGABLE)
    a = Segment(INPUT,node=A,color='orange').config(name='a',color='blue',state=DRAGABLE)
    b = Segment(INPUT,node=tail(a)).config(name='b',color='blue',state=DRAGABLE)
    c = Segment(tail(b),A).config(name='c',color='blue',state=DRAGABLE)
   

#---- test sugli input (con messaggio guida) ---- 18apr22
def esempio14():
    T = Point(INPUT,msg='seleziona un punto ...').config(name='T',color='blue',state=DRAGABLE)
    #s = Segment(INPUT,msg='adesso un segmento ...',color='orange').config(name='s',color='green',state=DRAGABLE) #ERR
    s = Segment(INPUT,msg='adesso un segmento ...').config(name='s',color='green',state=DRAGABLE)
    t = Segment(INPUT,msg='adesso un segmento ...',node=T).config(name='t',color='orange',state=DRAGABLE)
    r = Line(INPUT,msg='adesso una retta ...').config(name='r',color='green',state=DRAGABLE)
    k = Ray(INPUT,msg='adesso una semiretta ...').config(name='k',color='green',state=DRAGABLE)
    c = Circle(INPUT,msg='adesso una circonferenza ...').config(name='k',color='red',state=DRAGABLE)
   
    #message('seleziona segmento ...')
    #s1 = Segment(INPUT,node=T).config(name='s1',color='orange',state=VISIBLE)


#---- main ----
esempio13() #14
print('finito')

'''         
if __name__ == "__main__": 
   
    #----------------- main -------------------
    kinit()
    esempio15() #14
    #A = Point(INPUT,name='A',color='blue',state=DRAGABLE)
    #execprogram('test02.py')

    kwait() #sembra non servire se si esegue dall'IDLE
'''
