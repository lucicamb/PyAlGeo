# File: test_input.py 
# Date: 20 feb 23 - ok
# Note: test sui costruttori, sugli input (ed uso di moduli esterni)


#from mod_input import *   #cosi' se l'uso di sys (sopra) e' messo in DyGeo
from costruzioni import *

#grid()

#'''
#---- test sull'uso del messaggio guida ----
message('input di un punto...')
A = Point(INPUT,color='red',name='A',state=DRAGABLE)
waitclic()
B = Point(INPUT,color='blue',name='B',state=DRAGABLE)
C = Point(INPUT,msg='input punto C ...',color='brown',name='C',state=DRAGABLE)
#'''
#message('') #elimina il messaggio guida


'''
#input angolo
r = Ray(INPUT,msg='prima semiretta...',color='red',width=2,state=DRAGABLE)
#A = Point((2,3),color='green',state=DRAGABLE)
A = head(r)
#write('A=',A)
s = Ray(INPUT,msg='seconda semiretta...',node=A,color='red',width=2,state=DRAGABLE)
'''


'''
# circonferenza di dato centro e punto di passaggio - ok
c = Circle(Point(2,3),Point(1,4),color='red',state=DRAGABLE)  # width di default (LINESIZE)
center(c).config(color='blue',state=DRAGABLE)

message('messaggio di input di un punto ...') #sovrascritto se a seguire viene specificato msg
#p = Point(INPUT,msg='input punto...',color='blue',name='P',state=DRAGABLE)
p = Point(INPUT,color='red',name='P',state=DRAGABLE)
message('trascina il punto P')  #non si vede ERR
'''

'''
#---- costruttori di base ---- ok 16ago22
# definizione di primitive fisse
P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
s = Segment(P,Q,color='orange',name='s',state=DRAGABLE)
c = Circle(Point((1,2)),1.8,width=THICK,color='red',state=DRAGABLE)#.config(name='c',state=const.DRAGABLE,width=1,color='black')
r = Line(Point(2,-1),Point(3,4),color='blue',state=DRAGABLE)
A = Point(3,2,state=DRAGABLE)
B = Point(4,1,state=DRAGABLE)
r2 = Line(A,B,color='orange',state=DRAGABLE)
'''


'''
C = Point(1,4,color='green',state=DRAGABLE)
D = Point(-1,5,name='D',color='blue',state=DRAGABLE)

a = Line(A,B,color='red',state=DRAGABLE,width=2)
b = Line(C,D,color='orange',state=DRAGABLE,width=2)
T = inters(a,b)
#T.config(name='T',color='blue',state=OPERABLE) #con state>=OPERABLE label DRAGABLE, con visible no
T.config(name='T',color='blue',state=VISIBLE) #con state>=OPERABLE label DRAGABLE, con visible no



t = Segment(A,Point(4,2,name='C')).config(name='t',color='orange',state=DRAGABLE,width=3)
s = Segment(A,B,color='blue',state=VISIBLE)
#a = asse(A,B)
#M = medio(A,B)
C = Point(4,2,name='C')
p = perp(B,Line(A,C))
tail(t).config(color='black')
'''

'''
#---- primitive di base ---- ok
#input di di primitive in input
message('esegui gli input di un fascio proprio di rette ...')
s0 = Segment(INPUT,msg='segmento con attributi impostati...',name='s0')
p1 = Point(INPUT,msg='seleziona punto blu...',color='blue',name='P1',state=DRAGABLE)
s1 = Segment(INPUT,msg='seleziona segmento rosso...',color='red',name='s1',state=DRAGABLE)
l1 = Line(INPUT,msg='seleziona linea marrone...',color='brown',name='l1',state=SENSIBLE)
r1 = Ray(INPUT,msg='seleziona semiretta rosa...',color='pink',name='r1',state=DRAGABLE)
c1 = Circle(INPUT,msg='seleziona circolo verde...',color='green',name='c1',state=DRAGABLE)
'''

'''
#---- POINT ---- ok
#punti fissi
A = Point((3,2),state=DRAGABLE).config(name='A',color='green')  
B = Point((1,4)).config(name='B',color='red',state=DRAGABLE)  
C = Point(5,1).config(name='C',color='brown',state=DRAGABLE)  
D = Point(4,-1,name='D').config(name='newD',color='blue',state=DRAGABLE)  

#punto libero
message('input di un punto libero...')
#P = Point(INPUT,msg='seleziona punto P',name='P',color='red',state=DRAGABLE)
P = Point(INPUT,name='P',color='red',state=DRAGABLE)

#punti casuali
#P = Point(INPUT,color='red',state=DRAGABLE)#
for _ in range(400):
    #P = Point(RANDOM,color='red',state=DRAGABLE) #ok
    q = Point(RANDOM,on=(-4,-2,10,6),color='blue',state=DRAGABLE) #ok

'''

'''
#punto vincolato su linea - ok
r = Line(Point(-2,3),Point(4,1)).config(color='orange',state=DRAGABLE,width=THIN)
#message('input di un punto libero...')
P = Point(INPUT,on=r,msg='seleziona punto P',name='P',color='red',state=DRAGABLE)
'''


'''
#---- SEGMENT ---- ok
#input di un segmento A,B - 
message('input di un segmento AB ...')
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
B = Point(INPUT,node=A,state=DRAGABLE).config(name='B',color='green')
s = Segment(A,B,state=DRAGABLE).config(color='green')

#input di un segmento rigido A,B: muovendo A il segmento trasla 
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
x, y = coords(A)
B = Point((x+2,y+3),state=DRAGABLE).config(name='B',color='green')
s = Segment(A,B,state=DRAGABLE).config(color='green')

#segmento di estremi di nomi assegnati:
message('input di un segmento di nomi di vertici assegnati...')
s = Segment(INPUT,name=('P','Q'),color='magenta',state=DRAGABLE) #ERR: P e Q non va
a = asse(head(s),tail(s)).config(color='red',state=SENSIBLE)

#analogo a sopra con funzione esterna
message('... come prima, mediante funzione del modulo ...')
t = input_segmento('A','B','red')  #A e B non sono referenziabili con A e B
'''





'''
#---- LINE ---- ok

#rette di un fascio proprio
message('input di un fascio proprio di rette ...')
C = Point(INPUT,name='C',color='blue',state=DRAGABLE)
r = Line(INPUT,color='red',node=C,state=DRAGABLE)
s = Line(INPUT,color='red',node=C,state=DRAGABLE)

'''

'''
#---- triangolo rigido ---- ok
#input di un segmento triangolo rigido: muovendo A il triangolo trasla - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
x, y = coords(A)
B = Point((x+3,y),state=DRAGABLE).config(name='B',color='green')
C = Point((x,y+3),state=DRAGABLE).config(name='C',color='green')
Segment(A,B,state=DRAGABLE).config(color='green')
Segment(A,C,state=DRAGABLE).config(color='green')
Segment(B,C,state=DRAGABLE).config(color='green')
M = ((A+B+C)/3).config(color='red',name='M',state=DRAGABLE)
'''

''' 
#---- CIRCLE ---- ok
#---- input circ libera ----
message('input circonferenza libera...')
c = Circle(INPUT,color='blue',name='C',state=DRAGABLE)
c.config(color='red')



#---- input circ con centro fisso ----
message('input circonferenza con centro fisso invisibile...')
R = Point(INPUT,state=INVISIBLE)
f = Circle(INPUT,node=R,color='blue',name='F',state=DRAGABLE)

'''
