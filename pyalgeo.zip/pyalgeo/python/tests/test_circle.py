# File: test_circle.py 
# Date: 23 gen 23 - ..
# Note: test sulle funzioni dei moduli mod_input e costruzioni

#from mod_input import *
#from costruzioni import *

#import mod_input 
import costruzioni 


#from Triangolo import *

#from op_punti import * #funzione oltre

grid()

#s = input_segmento('P','Q','orange')  #ok

'''
#-- costruttori -- ok 13dic22
c0 = Circle(Point(1,2),1) #invisibile
c1 = Circle(Point(1,2),2,color='orange') #arancione ma invisibile
c2 = Circle(Point(1,2),2.5,state=DRAGABLE,color='red') #rosso solo sensibile
c3 = Circle(Point(1,2),3).config(state=DRAGABLE,color='brown') #arancione e dragabile
c4 = Circle(Point(1,2,color='blue',state=DRAGABLE),4,state=DRAGABLE,color='green') #blue e draggabile
'''

'''   
#-- test sul raggio di un circle -- 
c = Circle(INPUT,color='blue',state=DRAGABLE,width=MEDIUM)
r = radius(c)
write('raggio=',r)
'''

'''
#---- segmento su circ fisso traslabile ---- ok 23gen23 
#c2 = Circle(Point((-1,-1),2)).config(state=DRAGABLE,color='red')
c2 = Circle(Point((-3,-2),color='brown',name='c2',state=DRAGABLE),2,color='red',state=DRAGABLE)#.config(state=DRAGABLE,color='red')
t2 = Segment(INPUT,on=c2,color='blue',state=DRAGABLE)
'''


#'''
#-- circle traslabile di raggio variabile KValue -- ok 13feb23
A = Point(INPUT,msg='punto A?',name='A',color='blue',state=DRAGABLE)
B = Point(INPUT,msg='punto B?',name='B',color='blue',state=DRAGABLE)
c = Circle(Point(1,2),dist(A,B)).config(state=DRAGABLE,color='orange') #arancione e dragabile LENTO!
#c = Circle(Point(1,2),3).config(state=DRAGABLE,color='orange') #arancione e dragabile VELOCE
#'''


'''
#-- input circ libera -- ok 23gen23
c = Circle(INPUT,color='blue',name='C',state=DRAGABLE)
c.config(color='red')
write('circ c = ',c)  
write('radius(c)=',radius(c))
'''


'''
#-- circonferenza Centro-Punto -- ok 30ott22
#C = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
#P = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)

mes = 'seleziona il centro del circle...'
C = Point(INPUT,msg=mes,state=DRAGABLE).config(name='P',color='green')
mes = 'seleziona un punto...'
P = Point(INPUT,msg=mes,state=DRAGABLE).config(name='Q',color='green')
A = Circle(C,P,color='blue',name='c',state=DRAGABLE)
#A.config(color='green',state=SENSIBLE)  #serve per vedere A: sistemare!!!
'''


'''
#-- circonferenza Centro-Punto traslabile, con raggio fisso -- ok 23gen23 
#C = Point(INPUT,msg='centro?')  #ok
C = Point(INPUT,msg='centro?').config(state=INVISIBLE)
c = Circle(INPUT,node=C).config(state=INVISIBLE)
r = dist(C,Point(RANDOM,on=c))

#ok come segue:
#C1 = Point(C).config(color='brown',state=DRAGABLE)
#d = Circle(C1,r,color='red',state=DRAGABLE)

#d = Circle(Point(C),r).config(color='red',state=DRAGABLE)   #cosi' non si vede il centro
d = Circle(Point(C).config(color='brown',state=DRAGABLE),r).config(color='red',state=DRAGABLE) #ok
'''


''' versione alternativa a sopra - DA COMPLETARE ...
#-- circonferenza Centro-Punto con raggio fisso -- ok 10ago22 - SISTEMARE
C = Point(INPUT,msg='centro?').config(state=DRAGABLE)
c = Circle(INPUT,node=C).config(state=INVISIBLE)
#P1 = Point(RANDOM,on=c)
#write('P1=',P1)
#P2 = Point(P1)
#write('P2=',P2)
r = dist(Point(C),Point(Point(RANDOM,on=c)))
write('r=',r)
#C1 = Point(C).config(color='brown',state=DRAGABLE)
d = Circle(C,r).config(color='red',state=DRAGABLE)
'''

'''
#-- acquisizione di un circle INVISIBLE -- ok 30ott22
c = Circle(INPUT).config(state=INVISIBLE) #tutto invisibile
center(c).config(state=DRAGABLE)          #riattivato solo il centro
#c.config(state=DRAGABLE,color='green') #per prova
#center(c).config(state=INVISIBLE) #prova
for _ in range(10):
    Point(RANDOM,on=c,color='red',state=DRAGABLE)
'''


'''
#test sulla funzione kinter:pointOn e Point(RANDOM,...) - ok 1ago22
message('seleziona una circonferenza ...')
a = Circle(INPUT,color='blue',name='a',state=DRAGABLE)
message('seleziona un segmento ...')
s = Segment(INPUT,color='brown',name='s',state=DRAGABLE)
for _ in range(5):
    #pointOn(a).config(color='red',state=DRAGABLE)      #ok 
    #pointOn(s).config(color='green',state=DRAGABLE)    #ok
    Point(RANDOM,on=a).config(color='red',state=DRAGABLE)      #ok
    Point(RANDOM,on=s).config(color='green',state=DRAGABLE)    #ok
'''




'''
#input di un segmento vincolato su una circonferenza - ok
message('seleziona una circonferenza ...')
c = Circle(INPUT,color='blue',name='circ',state=DRAGABLE)
write('circ c = ',c)  

s = Segment(INPUT,msg='seleziona segmento rosso vincolato ...',on=c,color='red',name='s',state=DRAGABLE)
#s = Segment(INPUT,msg='seleziona segmento libero...',color='blue',name='s',state=DRAGABLE)

#l = Line(INPUT,msg='seleziona retta vincolato ...',on=c,color='orange',name='s',state=DRAGABLE)
write('seg s = ',s)
#write('lin l = ',l)
'''


'''
#input di un punto vincolato su una circonferenza invisibile - ok 13dic22
#c = Circle(O,2,color='red',name='c',state=INVISIBLE)
c = Circle(O,2,color='red',name='c',state=DRAGABLE)
P = Point(INPUT,state=DRAGABLE,on=c).config(name='P',color='green')
'''

'''
#circ per 3 punti - ok 13dic22 
P = Point((-2,2),).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3),).config(name='Q',color='green',state=DRAGABLE)
R = Point((0,4),).config(name='R',color='green',state=DRAGABLE)
#g = costruzioni.circonf3punti(P,Q,R)    # ok
g = Circle((P,Q,R))                     # ok
g.config(color='red',state=SENSIBLE) #serve per vedere g: sistemare!!!
'''


'''
#circ per centro C ed apertura AB - ok 7dic22
C = Point(INPUT,state=DRAGABLE).config(name='C',color='blue')
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
B = Point(INPUT,state=DRAGABLE).config(name='B',color='green')
c = Circle(C,A,B)        
c.config(color='red',state=SENSIBLE) 
'''


'''
#circ di diametro AB - ok 13dic22
A = Point(INPUT,state=DRAGABLE).config(name='A',color='blue')
B = Point(INPUT,state=DRAGABLE).config(name='B',color='blue')
c = Circle(med(A,B),dist(A,B)/2)        
c.config(color='red',state=SENSIBLE) 
'''


#-------- INPUT --------
''' ok
#---- input circ con centro e punto di passaggio ----
A = Circle(INPUT,msg='seleziona centro e poi punto di passaggio circ...',color='blue',name='a',state=DRAGABLE)

#---- input circ con centro fisso ----
#P = Point((3,2),state=DRAGABLE).config(name='P',color='green')
P = Point(INPUT,state=DRAGABLE,on=c).config(name='P',color='green')
P.config(color='orange')
d = Circle(INPUT,node=P,color='blue',name='D',state=DRAGABLE)

#---- input circ con raggio fisso ----
#Q = Point((2,1),state=DRAGABLE).config(name='Q',color='green')
Q = Point(INPUT,state=DRAGABLE).config(name='Q',color='green')
e = Circle(Q,1.5,color='red',name='E',state=DRAGABLE)
e.config(color='orange') #anche il punto Q diventa arancione; giusto?

#---- input circ con centro fisso ----
R = Point(INPUT,state=INVISIBLE)
f = Circle(INPUT,node=R,color='blue',name='F',state=DRAGABLE)

#---- input circ per 3 punti ----
B = Circle(INPUT,node=(),msg='circ per 3 punti...',color='blue',name='e',state=DRAGABLE) #ok
'''


'''
#---- input segmento e circ con centro su un estremo del segmento ---- ok 9ago21
#s = Segment(INPUT,color='green').config(name='s',state=DRAGABLE)
s = Segment(INPUT,color='green',state=DRAGABLE).config(name='s',state=DRAGABLE) #ERR: i vertci non risultano draggabili
f = Circle(head(s),1.5,color='blue',name='E',state=DRAGABLE)
f.config(color='red') #ERR: rende rosso anche il vertice di f: SIST
'''


'''
#---- circ avente raggio la distanza fra due punti ---- ok 6ago21
P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
C = Point(INPUT,state=DRAGABLE).config(name='C',color='green')
g = Circle(C,dist(P,Q),color='blue',name='g',state=DRAGABLE)
write('circ g = ',g)  
'''


'''
#input circ per 3 punti - caso (a) - non funziona (modificare def input, Circle(INPUT in wingra.py)
#P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
#Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
P = Point(INPUT,state=DRAGABLE).config(name='P',color='green')
Q = Point(INPUT,state=DRAGABLE).config(name='Q',color='green')
A = Circle(INPUT,node=(P,Q),msg='seleziona terzo punto della circ...',color='blue',name='c',state=DRAGABLE)
A.config(color='green',state=SENSIBLE)  #serve per vedere A: sistemare!!!
'''


'''
#circ per 3 punti fissi - caso (b) - ok 4set22
P = Point((-2,2),).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3),).config(name='Q',color='green',state=DRAGABLE)
R = Point((0,4),).config(name='R',color='green',state=DRAGABLE)
A = Circle((P,Q,R),color='blue',name='c',state=DRAGABLE)
A.config(color='red',state=SENSIBLE) #serve per vedere A: sistemare!!!
'''


'''
#modalita' alternativa (trova solo il centro)
_cons_color = 'gray'
_cons_width = 1
a = Circle(A,B,color=_cons_color,width=_cons_width,state=VISIBLE)
b = Circle(B,A,color=_cons_color,width=_cons_width,state=VISIBLE)
c = Circle(B,C,color=_cons_color,width=_cons_width,state=VISIBLE)
d = Circle(C,B,color=_cons_color,width=_cons_width,state=VISIBLE)
#C = inters(Line(a,b),Line(c,d)).config(color='orange',state=VISIBLE)
'''



