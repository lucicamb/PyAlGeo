# File: tarta02.py - ok
# Date: 6 set 21
# Note: esempio con la grafica della tartaruga
#       ERR: non gestisce correttamente la distanza della t. da un punto;
#       agganciare la t. ad un Kpoint dinamico ...

from kinter import * 

#---- main ----


col = ['black','blue','green','red']
penup()
setpos(1,1)
pendown()

P = here()
forward(1)
left(90)
forward(2)
Q = here()
move(P)
draw(Q)
show()


#'''
#---- spirale ----
for i in range(25):
   forward(0.2*i)
   left(90)
   color(col[i % len(col)])

# quadrato con move/draw/close
col = ['black','blue','green','red']
penup()
setpos(1,1)
pendown()
forward(1)
show()
#message('seleziona un punto ...')
#A = Point(INPUT,name='A',color='blue',state=DRAGABLE) #attende clic
#hide()
#'''

#'''
# grafo completo
a = [] # array dei vertici
move((-2,-2))
lato = 2
nver = 7
penup()
for i in range(nver):
    a += [here()]
    forward(lato)
    left(360/nver)
pendown()
color('red')
for i in range(nver):
    for j in range(i,nver):
        move(a[i])
        draw(a[j])

#'''


#'''
message('seleziona un punto ...')
A = Point(INPUT,name='A',color='blue',state=DRAGABLE) #attende clic
message('seleziona un altro punto ...')
B = Point(INPUT,name='B',color='green',state=DRAGABLE) #attende clic
message('')
#hide()
show()
d = tdist(A)
write('dist(tarta,A)=',d) #ok
move((2,-2)) # movimento della t.
T = here()  #punto dinamico della posizione corrente della (penna della) t.
T.config(name='T',color='red',state=DRAGABLE)   #come deve funzionare?
write('T=',T)
s = Segment(A,T,color='orange',state=DRAGABLE)
look(A)
forward(3)
look(B)

'''
#---- versione dinamica della t. ---- sospesa a sett. 21
#join(A) #per prova: ok con 2 join: vale l'ultimo
#join(B) #prova del 15lug21
#join(T)  #causa errore (?)
'''

    


 
