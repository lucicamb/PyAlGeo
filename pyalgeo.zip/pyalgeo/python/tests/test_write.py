# File: test_show.py 
# Date: 3 feb 23
# Note: test di scrittura sulla finestra delle show

from time import sleep

''' 
#---- prova base ----
A = Point(3,4,name='A',color='red',state=DRAGABLE)
show('A=',A)
m = 'input di un punto ...' 
B = Point(INPUT,msg=m,color='blue',state=DRAGABLE)
show('B=',B)
'''


'''
#---- prova 1 con Value ----
x = 10
X = Value(lambda:x,None)
show('X=',X)
for _ in range(10):
    X = X+1  #non modifica nella show
    sleep(.2)
'''


'''
#---- prova 2 con Value ---- quasi ok:visualizza solo a fine ciclo - 30gen23
P = Point(1,0)
x = coordx(P)
show('P=',P)
show('x=',x)

for _ in range(15):
    #P = P/2  #...non modifica nella show
    P._drag(1,1.1)   #funziona
    P._move()
    sleep(.4)
'''



#'''
#---- main ----
m = 'input di un punto ...' 
#A = Point(INPUT,name='A',msg=m,color='blue',state=DRAGABLE)
A = Point(INPUT,msg=m,color='blue',state=DRAGABLE)
B = Point(INPUT,name='B',msg=m,color='blue',state=DRAGABLE)
C = Point(INPUT,name='C',msg=m,color='orange',state=DRAGABLE)
D = Point(INPUT,name='D',msg=m,color='orange',state=DRAGABLE)
r = Line(C,D,color='red',state=VISIBLE)
t = Ray(A,C,color='brown',state=VISIBLE)
M = (A+B)/2
M.config(color='red',state=SENSIBLE) 
c = Circle(Point((1,2)),1.8).config(name='c',state=const.DRAGABLE,color='black')
s = Segment(A,B).config(color='red',state=DRAGABLE)
maggiore = coordx(A)>coordy(A)
show('coordx(A)>coordy(A)=',maggiore)

show(A)

#'''
show(A+O)
show('A = ',A)
show(A+B)
show('A+B=',A+B)
T = A
show(T)
show('B = ',B)
show('M = ',M)
show('c = ',c)
show('r = ',r)
show('s = ',s)
show('t = ',t)
show('dist(A,M) = ',dist(A,M))
#c = Circle(Point(1,2),1.8).config(name='c',state=const.DRAGABLE,width=1,color='black')
d = Circle(M,dist(A,M)).config(name='d',state=const.DRAGABLE,width=1,color='orange')
show('d = ',d)
R, S = inters(c,d)
show('punto R di intersezione = ',R)
show('punto S di intersezione = ',S)
t = Segment(R,S).config(width=1,color='green',state=SENSIBLE)
show('t(R,S) = ',t)
r = Line(A,M).config(width=1,color='orange',state=SENSIBLE,expand=False)
show('r(A,M) = ',r)
cost=1.23456789
pi = 3.141592
show(cost)
show('PI=',pi)
show('stringa solitaria')


show('A+B=',A+B)
write(str(A+B))
write('r(A,M)='+str(r))

#stringhe fisse
write('stringa fissa')
write(1234)
write('numero pi='+str(3.141592))
x = 4.123

for _ in range(5):
    #write('x='+str(x))
    #write('x='+"{:16.12f}".format(x))
    write('x='+"{:.15f}".format(x))
    x *= 17./3.

#'''