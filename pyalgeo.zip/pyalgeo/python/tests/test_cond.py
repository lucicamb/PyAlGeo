# File: test_cond.py - ..
# Date: 27 gen 23 
# Note: test sui valori ed attributi condizionali dinamici (CondObject, ...)
#       e sui confronto = != fra punti

#from kinter import *

#from costruzioni import * #piede 

grid()

'''
#-- test sui confronti di uguaglianza --
A = Point(2,3,color='red',state=DRAGABLE)
A1 = Point(2,3,color='red',state=DRAGABLE)
B = Point(2,3,color='blue',state=DRAGABLE)
C = A
D = Point(3,1,color='green',state=DRAGABLE)

write('A=',A)
write('B=',B)
write('C=',C)
write('D=',D)
write('(A==A1)=',A==A1)  #False
write('(A==B)=',A==B)    #False
write('(A==C) =',A==C)   #True
write('(A==D) =',A==D)   #False
write('uguale(A,A1)=',equal(A,A1))
write('uguale(A,B)=',equal(A,B))
write('uguale(A,C)=',equal(A,C))
write('uguale(A,D)=',equal(A,D))
'''

'''
#prova drag:
A = Point(2,3,name='A',color='red',state=DRAGABLE)
#B = Point(1,4,name='B',color='blue',state=DRAGABLE)
#s = Segment(A,B,color='green',name='s',state=VISIBLE,width=MEDIUM)
'''

''' 
#-- test di debug su children e parents - N.1 - ok
T = Point(-3.4,4.5,name='T',color='red',state=DRAGABLE) 
x = coordx(T) #AGGIUNGE UN CHILDREN a T
#c = coordx(T)<coordy(T)  #AGGIUNGE entrambe le coord DUPLICATI in T
#c = coordx(T)<3 #coordy(T)  #AGGIUNGE la coordx DUPLICATA in T
#col = CondValue(c,'orange','green')
#col.debug('di col')
#T.config(color=col) #<---------- causa RIC INF quando si trascina T
T.debug('di T')

A = Point(2,3,name='A',color='red',state=DRAGABLE)
#A = Point(2,3,name='A',color=col,state=DRAGABLE)
A.config(color=col)
A.debug('di A')
'''


''' 
#-- test di debug su children e parents - N.2
T = Point(-3.4,4.5,name='T',color='red',state=DRAGABLE) 
T.debug('di T')
A = Point(coordx(T),3,name='A',color='red',state=DRAGABLE)
A.debug('di A')
B = Point(coordx(A),-2,name='B',color='green',state=DRAGABLE)
B.debug('di B')
xa = coordx(A)
xa.debug('della coordinata xA')
xt = coordx(T)
xt.debug('della coordinata xT')
'''


'''
#======== test sui punti condizionaliizionale Cond ======== ok [27gen23]
# il punto C si collega al punto piu' vicino fra A e B
A = Point(2,3,name='A',color='blue',state=DRAGABLE)
B = Point(1,2,name='B',color='blue',state=DRAGABLE)
C = Point(4,1,name='C',color='brown',state=DRAGABLE)
cond = dist(C,A)<dist(C,B)
write('cond=',cond)
write('A=',A)
write('B=',B)
write('C=',C)
Q = CondPoint(cond,A,B)
x = Segment(C,Q,color='red',state=VISIBLE,width=MEDIUM)
write('x=',x)
'''



#======== tests sugli attributi condizionali ========

#---------------- test A ---------------------
'''
A = Point(2,3,name='A',color='red',state=DRAGABLE)
B = Point(1,4,name='B',color='orange',state=DRAGABLE)
#c2 = coordx(B)<coordy(B) 
c2 = coordx(A)<coordy(A)  #con questa condizione B non cambia colore
col2 = CondValue(c2,'orange','green')
write('col2=',col2)
A.config(color=col2) #causa RIC INF
B.config(color=col2) 

c  = coordx(B)<coordy(B)
cx = CondValue(c,coordy(B),coordx(B))
cy = CondValue(c,coordy(A),coordx(A))
#C = Point(-1,-2,name='C',color='black',state=DRAGABLE)
C = Point(cx,cy,name='C',color='black',state=DRAGABLE)

#P = Point(3,4,name='P',color='red',state=DRAGABLE)
P = Point(coordy(A),coordx(A),name='P',color='red',state=DRAGABLE)
Q = Point(5,2,name='Q',color=col2,state=DRAGABLE)
s = Segment(P,Q,state=DRAGABLE,color=col2,width=MEDIUM)
'''

#'''
#---------------- test B ---------------------
# 
#-- test sugli attributi condizionali -- parzialmente corretto - 27gen23
A = Point(2,3,name='A',color='red',state=DRAGABLE)
#A.debug('A appena creato')
c = coordx(A)<coordy(A)
#c.debug('condizione c')
write('c=',c)
col = CondValue(c,'red','blue')
#col.debug('condvalue col')
write('col=',col)

#caso 1: A cambia colore ok:
A.config(color=col) 
#A.debug('A dopo config')

#caso 2: B cambia colore trascinando A ok
B = Point(4,3,name='B',color=col,state=DRAGABLE)       

#caso 3: C cambia colore trascinando A ok
C = Point(coordy(A),2,name='C',color=col,state=DRAGABLE)   

#caso 4: C cambia colore trascinando A quasi - LA LABEL NON CAMBIA COLORE
r = Line(Point(-1,2),Point(4,5),name='r',color=col,state=DRAGABLE)

#caso 5: ERR: D cambia col solo quando viene mosso 
D = Point(-3,4,name='D',color='green',state=DRAGABLE)   
D.config(color=col) 

#caso 5: ERR: E non cambia colore
E = Point(INPUT,name='E',color=col,state=DRAGABLE)   




#---------------- test C ---------------------
''' va con i commenti, ma B non è reattivo; senza commenti => ric infinita
A = Point(2,3,name='A',color='red',state=DRAGABLE)
c = coordx(A)<coordy(A)
write('c=',c)
col = CondValue(c,'red','blue')
write('col=',col)
  
B = Point(4,5,name='B',color='black',state=DRAGABLE)   
c2 = coordx(A)<coordx(B)

col2 = CondValue(c2,'red','blue')
write('c2=',c2)

write('col2=',col2)
B.config(color=col2)  #causa ERRORE - termina il programma; ok con i commenti in #1671

write('A=',A)
write('B=',B) 
'''



'''
#---------------- test D ---------------------
#-- test sui valori condizionali -- ok 
A = Point(2,3,name='A',color='red',state=DRAGABLE)

#B = Point(4,1,name='B',color='blue',state=DRAGABLE)
#c = coordx(A)<coordx(B)
c = coordx(A)<coordy(A)
write('c=',c)
col = CondValue(c,'red','blue')
write('col=',col)

#x = CondValue(c,coordx(A),coordy(B))
#y = -2
#H = Point(x,y,name='H',color='green',state=VISIBLE)

#caso a: ok
#K = Point(1,4,name='K',color=col,state=DRAGABLE) #ok

#caso b: funziona se in graph si mette la parte che fa RIC INF
K = Point(1,4,name='K',color='brown',state=DRAGABLE)   
K.config(color=col) #... quasi: cambia colore solo quando viene dragato [8ott22]
'''


'''
#-- test sui valori condizionali multipli -- ok se si commenta in #1671 in graph
A = Point(2,3,name='A',color='red',state=DRAGABLE)
#col = CondValue(coordx(A)<0,'red','blue')  #ok
col = CondValue(coordx(A)<0,CondValue(coordy(A)<0,'red','blue'),CondValue(coordy(A)<0,'green','orange')) #ok
A.config(color=col)
'''


'''
#-- test sui valori dinamici e condizionali -- ok
A = Point(2,3,name='A',color='orange',state=DRAGABLE)
B = Point(1,2,name='B',color='red',state=DRAGABLE)
c = coordx(A)<coordx(B)
write('c=',c)
col = CondValue(c,'green','blue')
M = (A+B)/2
M.config(color=col)  
col2 = CondValue(c,'blue','pink')
H = Point(coordy(A),coordx(B),name='H',color=col2,state=DRAGABLE)
'''
