# File: test_attributi.py
# Date: 26 set 21
# Note: gestione degli attributi degli oggetti

grid()

A = Point((2,3),name='A',state=DRAGABLE)
B = Point((3,1),name='B',color='blue',state=DRAGABLE)
A.config(name='A1',color='red',state=VISIBLE)
C = Point(INPUT,name='C',msg='punto C?',state=DRAGABLE)
D = Point(INPUT,name='D',msg='punto D?',color='#EEBB00') #state DRAGABLE
C.config(color=B.color(),state=A.state(),name=C.name()+'1')


'''
B = Point(INPUT,name='B',msg='input punto...',color='red',state=DRAGABLE)
s = Segment(A,B,color='orange',state=VISIBLE)
C = Point(INPUT,name='C',msg='input punto su segmento...',on=s,color='red',state=DRAGABLE)
d = dist(A,B)
#c = Circle(A,d/2,color='blue',state=DRAGABLE)      # (1) ok
#c = Circle(A,med(A,B),color='blue',state=DRAGABLE) # (2) equivale a (1) (ma piu' veloce)
#c = Circle(A,B,color='blue',state=DRAGABLE)        # (3) quasi come (1)
c = Circle(A,2.5,color='blue',state=DRAGABLE)       # (4) circle mobile ma di raggio costante

Text((3,-3),"distanza = {0}",d, color='red')
D = Point(INPUT,name='D',msg='input punto su circle...',on=c,color='red',state=DRAGABLE)
E = Point(RANDOM,name='E',on=c,color='green',state=DRAGABLE)
'''


