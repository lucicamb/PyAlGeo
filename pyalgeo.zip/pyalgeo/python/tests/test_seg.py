# File: test_seg.py 
# Date: 11 giu 21 - ..
# Note: test sui segmenti

# acquisizione interattiva di un segmento rigido
# traslabile su primo punto
def inputSegmentoRigido(col) -> Segment:
    A = Point(INPUT,msg='primo punto').config(name='',color=col,state=DRAGABLE)
    B = Point(INPUT,node=A,msg='secondo punto').config(name='',color=col,state=INVISIBLE)
    T = (A+clone(B-A)).config(color=col,state=SENSIBLE) #serve color!
    s = Segment(A,T,color='orange',name='c') #,state=DRAGABLE) #ok
    return s


# acquisizione interattiva di un triangolo rigido ... DA COMPLETARE
# traslabile su primo punto
def inputTriangoloRigido(col):
    A = Point(INPUT).config(name='A',color=col,state=DRAGABLE)
    B = Point(INPUT,node=A).config(name='',color=col,state=INVISIBLE)
    #   c = Segment(A,B,color='red',name='c',state=SENSIBLE) 
    C = Point(INPUT,node=B).config(name='',color=col,state=INVISIBLE)
    
    
    Tc = (C+(Point(A)-A)).config(name='Tc',color='blue',state=DRAGABLE)
    Tb = (B+(Point(A)-A)).config(name='Tb',color='blue',state=DRAGABLE)
    #Ta = (B+clone(B-C)).config(color='blue',state=SENSIBLE)
    c = Segment(A,Tc,color='orange',name='c',state=DRAGABLE) #ok
    b = Segment(A,Tb,color='orange',name='c',state=DRAGABLE)
    a = Segment(Tb,Tc,color='orange',name='c',state=DRAGABLE) 
   
    return [A,B,C]

'''---- input di segmenti liberi ----
#a = Segment(INPUT,msg='seleziona un segmento libero...',state=DRAGABLE).config(name='a',color='red')
#s = Segment(INPUT,msg='seleziona un segmento libero...',state=DRAGABLE,name='s',color='red') #ok

#ERR: se b si aggancia ad a diventa tutto blu ... sistemare in graph:config#1020
#b = Segment(INPUT,msg='seleziona un segmento con primo punto su a ...').config(name='b',color='blue',state=DRAGABLE)
'''


#''' 
#---- input di un segmento rigido ---- ok 9ago22
# Nota: Point(A) genera un clone invisibile di A 
message('input di un segmento ...') 
A = Point(INPUT,name='A',color='blue',state=DRAGABLE)
#B = Point(INPUT,node=A,state=INVISIBLE)  #punto invisibile, ma setta l'attr. INVIS
B = Point(INPUT,node=A).config(state=INVISIBLE)  #punto invisibile, ma non cambia att. cor.
#B.config(state=INVISIBLE) #B viene reso invisibile (oppure da eliminare...)
message('...') # clear

#C = Point(A).config(name='C',color='red',state=DRAGABLE) #clone di A
#C = Point(A) # clone di A invisibile
#T = (B-C+A).config(color='brown',name='B',state=DRAGABLE)

T = (B-Point(A)+A).config(color='brown',name='B',state=DRAGABLE)
v = Segment(A,T,color='orange',state=DRAGABLE)
#'''



'''
# segmento rigido di lunghezza unitaria - ok
P = Point(INPUT).config(name='',color='green',state=DRAGABLE)
v = Segment(P*1.,P+U,color='orange') #.config(name='v',color='green',state=DRAGABLE) #ok
''' 


'''---- input di un segmento rigido traslabile ---- ok
#cer = Circle(INPUT,color='blue',state=DRAGABLE)
#A = Point(INPUT,name='',color='green',state=DRAGABLE)
#B = Point(INPUT,name='',color='green',state=VISIBLE)
A = Point(INPUT).config(name='',color='green',state=DRAGABLE)
#B = Point(INPUT).config(name='',color='green',state=DRAGABLE)
#B = Point((2.,3.),color='blue',state=DRAGABLE)
B = Point(INPUT).config(name='',color='green',state=INVISIBLE)
#T = (A+clone(B-A)).config(color='blue',state=VISIBLE) #serve color!
T = (A+clone(B-A)).config(color='blue',state=SENSIBLE) #serve color!
c = Segment(A,T,color='orange',name='c') #,state=DRAGABLE) #ok
#c = Segment(A,A+clone(B-A),color='orange',name='c') #,state=DRAGABLE) #ok
'''

'''
#s = inputSegmentoRigido('red')
inputTriangoloRigido('brown')
'''

'''
#---- input di un triangolo rigido ----
A = Point(INPUT).config(name='',color='green',state=DRAGABLE)
B = Point(INPUT).config(name='',color='green',state=DRAGABLE)
C = Point(INPUT).config(name='',color='green',state=DRAGABLE)
#T = (A+clone(B-A)).config(color='blue',state=VISIBLE) #serve color!
Tc = (A+clone(B-A)).config(color='blue',state=SENSIBLE)
Tb = (A+clone(C-A)).config(color='blue',state=SENSIBLE)
#Ta = (B+clone(B-C)).config(color='blue',state=SENSIBLE)

c = Segment(A,Tc,color='orange',name='c') #,state=DRAGABLE) #ok
b = Segment(A,Tb,color='orange',name='c')
a = Segment(Tb,Tc,color='orange',name='c') 
'''

#a = Segment(INPUT,node=P,color='orange').config(name='c',color='green',state=DRAGABLE)

                                                                                                            

#s = Segment(INPUT,msg='seleziona un segmento ...',node=T).config(name='t',color='orange',state=DRAGABLE)

'''
T = Point(INPUT,msg='seleziona un punto ...').config(name='T',color='blue',state=DRAGABLE)
    #s = Segment(INPUT,msg='adesso un segmento ...',color='orange').config(name='s',color='green',state=DRAGABLE)
    t = Segment(INPUT,msg='adesso un segmento ...',node=T).config(name='t',color='orange',state=DRAGABLE)
    #r = Line(INPUT,msg='adesso una retta ...').config(name='r',color='green',state=DRAGABLE)
    #k = Ray(INPUT,msg='adesso una semiretta ...').config(name='k',color='green',state=DRAGABLE)
    #c = Circle(INPUT,msg='adesso una circonferenza ...').config(name='k',color='red',state=DRAGABLE)
   
    #message('seleziona segmento ...')
    #s1 = Segment(INPUT,node=T).config(name='s1',color='orange',state=VISIBLE)
'''






