# File: test_stati.py 
# Date: 14 dic 22 - ok
# Note: test sulla gestione dell'attributo stato

grid()

#---- test su config ---- ok 14dic22
A = Point(2,3,name='A',color='blue',state=DRAGABLE)
A.config(name='newA')
s = Segment(INPUT,color='red',state=DRAGABLE)
s.config(name='s')
M = head(s).config(name='M')  
N = tail(s)
N.config(name='N')  


'''
#s = Segment(INPUT,msg='segmento con attributi impostati...',name='s0')
#s.config(color='red')
A = Point(-4,0,name='A',color='blue',state=DRAGABLE)
#A = Point(-4,0,name='A',color='blue',state=OPERABLE)
#A = Point(-4,0,name='A',color='blue',state=INVISIBLE)
#A.config(color='red',state=INVISIBLE)

B = Point(4,5,name='B',color='red',state=OPERABLE) # ok con solo questo
B.config(name='B1',color='green',state=SENSIBLE)  #B1 dragga ok

r = Line(A,B,name='r',color='orange',state=DRAGABLE)

r.config(color='red',width=THIN)

#B = Point(4,5,name='B',color='red',state=OPERABLE) #

message('finito...')
'''
