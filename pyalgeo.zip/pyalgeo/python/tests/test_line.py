# File: test_line.py 
# Date: 24 gen 23 - ..
# Note: test sulle rette

#''' 
#---- costruttori di retta con vettore direttore dinamico ---- ok 23gen23 
P = Point((1,2),name='P',color='grey',state=DRAGABLE)                  #punto libero
Q = Point(coordy(P),coordx(P),name='Q',color='blue',state=DRAGABLE)    #punto vincolato
R = Point(coordx(Q),5,name='R',color='brown',state=DRAGABLE)           #punto semilibero
write('P=',P)
write('Q=',Q)
write('R=',R)

r1 = Line(P,(2,3)).config(color='green',width=2,state=DRAGABLE) 
write('r1=',r1)  #ok
r2 = Line(R,(coordx(P),coordy(P))).config(color='blue',width=2,state=DRAGABLE) #no la write(r2)
write('r2=',r2)  #no l'eq
r3 = Line(R,30).config(color='brown',width=2,state=DRAGABLE) #inclinata a 30 gradi - ok
write('r3=',r3)  #ok
r4 = Line(R,coordx(P)*coordy(P)).config(color='red',width=2,state=DRAGABLE) #inclinata variabile - ok
write('r4=',r4)  #ok l'eq

A = Point((4,2),name='A',color='grey',state=DRAGABLE)
B = Point((5,1),name='B',color='grey',state=DRAGABLE)
C = Point((5,1),name='C',color='grey',state=DRAGABLE)

# NOTA: in drag della retta r che segue vengono creati KValues, ma SERVONO! 
# cfr. kline.py._setcoords, linea 88 ca
r = Line(A,(coordx(P),coordy(P))).config(color='green',width=2,state=DRAGABLE) 
write('r=',r)

s = Line(B,C,width=1,color='blue',name='s',state=VISIBLE)
write('s=',s)
s = Line(A,(1,2)).config(color='green',width=2,state=DRAGABLE)  
t = Line(A,(1,2),name='t').config(color='green',width=2,state=DRAGABLE)  
write('t=',t)
v = Segment(A,P,name='v',color='green',width=2,state=DRAGABLE) 
write('v=',v)
#'''


'''
#---- rette perpendicolari e ruotabili ----- ok 23gen23
r = Line(INPUT,color='red',state=DRAGABLE)
P = Point(INPUT,on=r).config(name='',color='green',state=DRAGABLE)
dx, dy = getdxdy(r)
write('dx=',dx)
write('dy=',dy)
s = Line(P,(dy,-dx),color='blue',state=DRAGABLE)
''' 



'''
#-- test base -- ok 23gen23
s = Segment(INPUT,name='s',color='red',state=DRAGABLE,width=MEDIUM)
A = head(s)
B = tail(s)
write('A=',A)
write('B=',B)
'''


'''
#---- input segmento su una retta ---- ok 23gen23 MA MUOVENDO LA RETTA IL SEGMENTO CAMBIA: SISTEMARE
li = Line(INPUT,color='red',state=DRAGABLE) 
t = Segment(INPUT,on=li,color='green',state=DRAGABLE) 
'''



'''
# input di segmenti - .. 4ago22 

#s1 = Segment(INPUT) #prende gli attributi settati sulla GUI
#s1 = Segment(INPUT,msg='segmento...') #prende gli attributi settati sulla GUI
#s2 = Segment(INPUT,color='orange').config(name='s',color='green',state=DRAGABLE) #verde solo il segmento
#s3 = Segment(INPUT,color='brown',state=DRAGABLE) #tutto brown
#s4 = Segment(INPUT,color='red',state=DRAGABLE)

#s5 = Segment(INPUT,node=Point(INPUT,on=s1,color='red'),color='blue',state=DRAGABLE) #ok 
#s5 = Segment(INPUT,node=Point(INPUT,on=s1,color='red'),Point(INPUT,on=c,color='black'),color='blue',state=DRAGABLE) #no

#ok con le due che seguono:
#P = Point(INPUT,on=s1,color='red')
#s5 = Segment(INPUT,node=P,on=c,color='blue',state=DRAGABLE) #..

#s5 = Segment(INPUT,node=Point(INPUT,on=s1,color='red'),on=c,color='blue',state=DRAGABLE) #..

#A = Point(INPUT)
#B = Point(INPUT)
#s6 = Segment(A,B).config(color='red',state=DRAGABLE)

#-- costruttori con angolo ---
#s7 = Segment(Point(INPUT),30).config(color='red',state=DRAGABLE)   #ERR MAL SEGNALATO
s7 = Segment(Point(INPUT),(2,30)).config(color='red',width=1,state=DRAGABLE)      #ok
l7 = Line(Point(INPUT),90).config(color='green',width=2,state=DRAGABLE)   #ok
r7 = Ray(Point(INPUT),60).config(color='brown',width=3,state=DRAGABLE)   #ok


#c = Circle(Point(1,2),3,color='orange')
#P=Point(INPUT,on=s1,color='red')
#s5 = Segment(Point(INPUT,on=s1,color='red'),Point(INPUT),color='blue',state=DRAGABLE)

#r = Line(P,(1,3),color='red',state=DRAGABLE)        #ok
#r = Line(P,coords(P),color='blue',state=DRAGABLE)   #ok
#r = Line(P,92,color='blue',state=DRAGABLE)          #ok
#r = Line(P,coordx(P),color='blue',state=DRAGABLE)   #ok
''' 

'''
#-- linea verticale ruotabile -- ok 13dic22  
A = Point(1,1,name='A',color='blue',state=DRAGABLE)
B = Point(1,4,name='B',color='green',state=DRAGABLE)
r = Line(A,B).config(color='red',name='M',state=VISIBLE)
write('r=',r)
'''


'''
#-- drag di un punto su retta e circle -- ok 23gen23
#P = Point(5,1,color='blue',state=DRAGABLE)
#write('P=',P)
a = Line(Point(2,2,color='red',state=DRAGABLE),Point(5,2,color='red',state=DRAGABLE),name='a',color='red',state=DRAGABLE)
write('a=',a)
b = Line(Point(3,4,color='red',state=DRAGABLE),Point(1,3,color='red',state=DRAGABLE),name='b',color='blue',state=DRAGABLE)
write('b=',b)
c = Circle(Point(1,2),3).config(state=DRAGABLE,color='brown') #arancione e dragabile
#c = Circle(Point(1,2,state=DRAGABLE,color='blue'),3,width=MEDIUM,name='c',state=DRAGABLE,color='brown') #arancione e dragabile
write('c=',c)
P = Point(INPUT,on=a,state=DRAGABLE,color='blue')  
Q = Point(INPUT,on=b,state=DRAGABLE,color='blue')  
R = Point(INPUT,on=c,state=DRAGABLE,color='green')
'''



'''
# intersezione retta-retta retta-circle - ok
a = Line(Point(3,4),Point(1,2),color='red',state=DRAGABLE)
b = Line(Point(-3,1),Point(2,-1),color='blue',state=DRAGABLE)
c = Circle(Point(-3,1),4,color='orange',state=DRAGABLE)
P, Q = inters(a,c)
P.config(color='brown',state=SENSIBLE)
T = inters(a,b)
T.config(color='green',state=SENSIBLE)
'''


'''
# 2 rette perpendicolari di centro mobile - ok 22gen23
P = Point(INPUT).config(name='P',color='green',state=DRAGABLE)
Q = Point(INPUT).config(name='Q',color='green',state=DRAGABLE)
#r = Line(P,(1,2),color='red',state=DRAGABLE)
#s = Line(P,(2,-1),color='red',state=DRAGABLE)
dx = coordx(Q)
dy = coordy(Q)
r = Line(P,(dx,dy),color='red',state=DRAGABLE)
s = Line(P,(-dy,dx),color='red',state=DRAGABLE)
write('r=',r)
write('s=',s)

#come segue funziona:
#T = Line 
T = Segment                                         
t = T(P,(2,7),color='orange',state=DRAGABLE) 
#t = T(P,Q,color='orange',state=DRAGABLE)  
write('t=',t)
'''


'''
#-- costruttore retta con inclinazione fissa -- ok 13dic22
P = Point(2,3,name='P',color='blue',state=DRAGABLE)
r = Line(P,(2,9),name='r',color='red',state=DRAGABLE,width=MEDIUM) 
#r = Line(P,coords(P),color='blue',state=DRAGABLE)   #ok
#r = Line(P,92,color='blue',state=DRAGABLE)          #ok
#r = Line(P,coordx(P),color='blue',state=DRAGABLE)   #ok
'''


'''
# rette-segmenti di dato coefficiente angolare - ok 13dic22 
P = Point(INPUT).config(name='',color='green',state=DRAGABLE)
T = Line #Ray  #Line   #Segment
r = T(P,Point(4,5,color='green',state=DRAGABLE),color='brown',state=DRAGABLE)        #ok
r = T(P,(1,3),color='red',state=DRAGABLE)        #ok
r = T(P,(.2,.8),color='red',state=DRAGABLE)        #ok
r = T(P,coords(P),color='blue',state=DRAGABLE)   #ok
r = T(P,92,color='orange',state=DRAGABLE)        #ok
r = T(P,coordx(P),color='brown',state=DRAGABLE)   #ok
''' 


