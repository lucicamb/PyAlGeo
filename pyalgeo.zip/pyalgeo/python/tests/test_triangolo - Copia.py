# File: test_triangolo.py 
# Date: 25 nov 22 - ok (un po' lento)
# Note: test della classe Triangolo

#from mod_input import *
#from costruzioni import *
from Triangolo import *

grid()

#t = Triangolo()   #input di un triangolo
#setcolor('red')
#t = Triangolo(color='red',vertices=('P','Q','R'))   #input di un triangolo
message('seleziona i tre vertici del triangolo')
t = Triangolo(vertices=('A','B','C'))   #input di un triangolo


write('area(t)=',area(t)) 
write('fperimetro(t)=',fperimetro(t))
write('perimetro(t)=',t.perimetro())

I = incentro(t).config(color='red',state=SENSIBLE)  #ok
write('incentro=',I)

c1 = circinscr(t).config(color='red',state=SENSIBLE) 
write('c1 inscritto=',c1)

c2 = circcirc(t).config(color='green',state=SENSIBLE)
write('c2 circoscritto=',c2)









