# File: test_drag.py 
# Date: 10 gen 23 
# Note: test sulle operazioni di drag, per vedere il corretto
#       passaggio in primo piano degli elementi che vengono spostati

#from mod_input import *  # a cosa serve?

'''
#---- test per riconoscere i 'colli di bottiglia' in drag - caso 1 ----
A = Point((2,3),name='A',color='red',state=DRAGABLE)
B = Point((1,4),name='B',color='blue',state=DRAGABLE)
k = Segment(A,B,color='brown',name='k',state=DRAGABLE)
M = (A+B)/2
write('xM=',coordx(M))
'''

#'''
#---- test per riconoscere i 'colli di bottiglia' in drag - caso 2 ----
A = Point((1,3),name='A',color='red',state=DRAGABLE)
A.dump(msg='punto A:')
B = Point((6,2),name='B',color='blue',state=DRAGABLE)
s = Segment(A,B,name='s',color='red',state=DRAGABLE,width=MEDIUM)
s.dump(msg='segmento s:')

K = Point(coordx(A),coordy(B),name='K',color='black',state=VISIBLE)
K.dump(msg='punto K:')
write('K=',K)


#'''
C = Point((5,4),name='C',color='green',state=DRAGABLE)
r = dist(A,B)
#r = coordx(A)-1  #no
#r = coordx(A)  #..
#r=2  #ok
write('r=',r)

#c = Circle(C,A,color='red',state=DRAGABLE,width=MEDIUM) #ok, non aggiunge succ in drag

#P = Point(coordx(B),coordy(A))  #ok
#P = Point(coordx(B),r)  #ok
#P = Point(coordx(C)+r,coordy(C)) #ok
#c = Circle(C,P,color='red',state=DRAGABLE,width=MEDIUM) #ok, non aggiunge succ in drag

#c = Circle(C,2,color='red',state=DRAGABLE,width=MEDIUM)  #ok, non aggiunge succ in drag
c = Circle(C,r,color='red',state=DRAGABLE,width=MEDIUM)  #ERR: aggiunge succ in drag

write('c=',c)

'''
write('c=',c)
#write('r=',r)
#r.debug(msg='raggio r:')
#C.debug(msg='punto C:')
'''

#A.dump(msg='punto A alla fine:') #questo dump e' ESAGERATO: SISTEMARE!!!!! [10gen23]
#c.dump(msg='circle c:')






'''
#---- test per riconoscere i 'colli di bottiglia' in drag - caso 3 ---- ok, no duplicati
A = Point((2,3),name='A',color='red',state=DRAGABLE)
B = Point((1,4),name='B',color='blue',state=DRAGABLE)
c = Circle(A,B,color='red',state=DRAGABLE,width=MEDIUM)
write('c=',c)
'''

'''
#---- test su drag e primo piano delle entita' ----
#s = Segment(INPUT,name=('P','Q'),color='red',state=DRAGABLE)
#t = Segment(INPUT,name=('R','S'),color='blue',state=DRAGABLE)

P = Point((4,5),name='P',color='brown',state=DRAGABLE)

A = Point((2,3),name='A',color='red',state=DRAGABLE)
B = Point((1,4),name='B',color='blue',state=DRAGABLE)
k = Segment(A,B,color='brown',name='k',state=DRAGABLE)
'''

'''
#---- segmento di lunghezza fissa ancorato agli assi ---- ok
#asseX = Ray(O,U,color='red',state=SENSIBLE)
#asseY = Ray(O,Point((0,1),state=INVISIBLE),color='blue',state=SENSIBLE)
asseY = Ray(O,Point((0,1),state=INVISIBLE),state=INVISIBLE)
k = 5
#sx = Segment(O,Point((k,0),state=INVISIBLE),color='blue',state=SENSIBLE)
sx = Segment(O,Point((k,0),state=INVISIBLE),state=INVISIBLE)
#A = Point(INPUT,on=asseX,name='A',color='red',state=DRAGABLE)  #funziona
A = Point(INPUT,on=sx,name='A',color='red',state=DRAGABLE)
#a = Circle(Point((3,0),on=asseX,state=DRAGABLE),2,color='blue',state=DRAGABLE)
#a = Circle(A,k,color='blue',state=DRAGABLE) #ok
a = Circle(A,k)
#P, Q = inters(a,asseY)  #non si vedono
B, _ = inters(a,asseY)  # il ris e' una tupla!
B.config(state=SENSIBLE,name='B',color='red')
s = Segment(A,B,color='red',state=DRAGABLE)
'''




