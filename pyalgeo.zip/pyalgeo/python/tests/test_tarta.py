# File: test_tarta.py - ok
# Date: 17 feb 23
# Note: esempi sulla grafica della tartaruga

'''
#---- test basico ---- ok 17feb23
a = getdir()
show('angolo iniziale della t.=',a)
write('angolo iniziale della t.='+str(a)) 
penup()
forward(2)
right(45)
show('angolo dopo della t.=',getdir())
write('posizione t. ='+str(getpos()))
show()  #visualizza la t.
pendown()
setcol('blue')
forward(3)
setpos(1,1)
pendown()
forward(1)
left(90)
forward(1)  
setpos(-2,-2)
col = ['black','blue','green','red']
for i in range(24):
    forward(0.2*i)
    left(90)
    setcol(col[i % len(col)])
A = Point((4,2),color='red',state=DRAGABLE)
d = dist(A)
show('dist(turtle,A)=',d)
look(A)
setcol('orange')
forward(10)
show('dopo: dist(turtle,A)=',dist(A))
write('penna su = '+str(ispendown()))
'''


'''
#-- test sulle operazioni di base no OO -- ok 17feb23
# disegna un quadrato ed un poligono, staccati
pendown()
home()
setcol('red')
hide()
show('posizione statica=',pos())
#show('posizione dinamica=',dpos())
for _ in range(4):
    forward(3)
    left(90)
jump(5)
hide()
show()
setcol('blue')
n = 16
for _ in range(n):
    forward(2)
    right(360/n)
    point()
show()
'''    
    
'''
#---- test (come sopra) sulle operazioni di base in modalita' OO - ok 17feb23
t = Turtle()
t.pendown()
t.home()
t.setcol('red')
t.hide()
#show('posizione statica=',t.dpos())
show('posizione dinamica=',t.pos())
for _ in range(4):
    t.forward(3)
    t.left(90)
t.jump(5)
t.hide()
t.show()
t.setcol('blue')
n = 16
for _ in range(n):
    t.forward(2)
    t.right(360/n)
    t.point()
t.show()
'''      
    

''' 
# disegno di un triangolo rettangolo - ok 17feb23
penup()
setpos(1,1)
pendown()
P = pos()
forward(1)
left(90)
forward(2)
Q = pos()
move(P)
draw(Q)
show()
'''

'''
#---- ottagono dragabile ---- ok 17feb23
penup()
P0 = pos()
P0.config(color='blue',state=DRAGABLE)
P1 = P0
n = 16
for _ in range(n-1):
    forward(2)
    P2 = dpos()
    P2.config(color='blue',state=DRAGABLE)
    Segment(P1,P2,color='red',state=DRAGABLE,width=MEDIUM)
    P1 = P2
    right(360/n)
Segment(P1,P0,color='red',state=DRAGABLE,width=MEDIUM) 
'''  

'''
#---- spirale ---- ok
col = ['black','blue','green','red']
#home()
for i in range(25):
   forward(0.2*i)
   left(90)
   setcol(col[i % len(col)])
'''


'''  ok - quasi [*]
message('seleziona un punto ...')
A = Point(INPUT,name='A',color='blue',state=DRAGABLE) #attende clic
message('seleziona un altro punto ...')
B = Point(INPUT,name='B',color='green',state=DRAGABLE) #attende clic
message('')
#pendown()
#hide()
show()
d = dist(A) #e' dinamico, ma solo se si sposta A   [*]
show('dist(tarta,A)=',d) #DataObject che dipende da A (e non dalla t.)
T = pos()  #pos attuale della t. (non dinamico)
d2 = dist(B,T)
show('dist(t,B)=',d2) #ok
'''



    


 
