# File: test_moduli.py 
# Date: 17 ago 21 - ok
# Note: test sulle funzioni dei moduli mod_input e costruzioni

from mod_input import *
from costruzioni import *
from Triangolo import *

kgrid()

'''
s = input_segmento('P','Q','orange')  #ok
#s.config(color='green')  #ERR: modifica solo il segmento (no vertici e label)
'''

'''
s = input_quadrilatero('blue')  #ok 15ago21
#s.config(color='red')
'''

#'''
p = input_poligono('blue')  #ok 15ago21
#print('Poligono=',p)
write('perimetro=',perimetro_poligono(p))
#s.config(color='red')
#'''



#input di un quadrilatero
#q = 

'''
#input di un singolo Point - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='red')
'''

'''
#input di un singolo Segment - ok
s = Segment(INPUT,msg='seleziona segmento rosso...',color='red',name='s',state=DRAGABLE)
write('seg s = ',s)  
'''

'''
#input di un segmento rigido A,B: muovendo A il segmento trasla - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
x, y = coords(A)
B = Point((x+2,y+3),state=DRAGABLE).config(name='B',color='green')
s = Segment(A,B,state=DRAGABLE).config(color='green')
'''


'''
# definizione di primitive fisse
P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
s = Segment(P,Q,color='orange',name='s',state=DRAGABLE)
c = Circle(Point((1,2)),1.8,color='red',state=DRAGABLE)#.config(name='c',state=const.DRAGABLE,width=1,color='black')

#input di di primitive in input
p1 = Point(INPUT,msg='seleziona punto blu...',color='blue',name='P1',state=DRAGABLE)
s1 = Segment(INPUT,msg='seleziona segmento rosso...',color='red',name='s1',state=DRAGABLE)
l1 = Line(INPUT,msg='seleziona linea marrone...',color='brown',name='l1',state=SENSIBLE)
r1 = Ray(INPUT,msg='seleziona semiretta rosa...',color='pink',name='r1',state=SENSIBLE)
c1 = Circle(INPUT,msg='seleziona circolo verde...',color='green',name='c1',state=DRAGABLE)

#input di un Point con nodo su un altro - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='red')
B = Point(INPUT,node=A,state=DRAGABLE).config(name='B',color='blue')
#'''

'''
#input di un segmento A,B - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
B = Point(INPUT,node=A,state=DRAGABLE).config(name='B',color='green')
s = Segment(A,B,state=DRAGABLE).config(color='green')
'''



''' ok
#input di un segmento triangolo rigido: muovendo A il triangolo trasla - ok
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
x, y = coords(A)
B = Point((x+3,y),state=DRAGABLE).config(name='B',color='green')
C = Point((x,y+3),state=DRAGABLE).config(name='C',color='green')
Segment(A,B,state=DRAGABLE).config(color='green')
Segment(A,C,state=DRAGABLE).config(color='green')
Segment(B,C,state=DRAGABLE).config(color='green')
M = ((A+B+C)/3).config(color='red',name='M',state=DRAGABLE)
'''

'''
#input di un triangolo A,B,C
A = Point(INPUT,state=DRAGABLE).config(name='A',color='green')
B = Point(INPUT,node=A,state=DRAGABLE).config(name='B',color='green')
s = Segment(A,B,state=DRAGABLE).config(color='green')
#Segment(A,B,state=DRAGABLE).config(color='green')
s.config(name='c')
C = Point(INPUT,node=B,state=DRAGABLE).config(name='C',color='green')
#s = Segment(B,C,state=DRAGABLE).config(color='green')
#s = Segment(C,A,state=DRAGABLE).config(color='green')
Segment(B,C,state=DRAGABLE).config(color='green')
Segment(C,A,state=DRAGABLE).config(color='green')
'''

#C.config(name='C')  #ERR: SIST!!
#Segment(A,C,state=VISIBLE,color='green')          # verde DIVERSO che da sotto:
#Segment(A,C,state=VISIBLE).config(color='green')   # perche'????
#'''


'''
#prova di rb con doppio nodo (a V)
P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
A = Point(INPUT,node=(P,Q),msg='seleziona punto A...',color='blue',name='A',state=DRAGABLE)
'''










