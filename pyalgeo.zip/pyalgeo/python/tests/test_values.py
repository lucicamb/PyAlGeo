# File: test_values.py
# Date: 27 nov 22
# Note: test delle operazioni con Values

A = Point(INPUT,name='A',color='red',state=DRAGABLE)

n = 1.23
x = coordx(A)
y = coordy(A)
a = x+y
b = x-y
c = x*y
d = x/y
z = x/0
e = (-x-a*y)/(a*a-4*d-math.sin(2))
print('type(A) =',type(A),'  isinstance =',isinstance(A,KValue))
print('type(e) =',type(e),'  isinstance =',isinstance(e,KValue))
print('type(n) =',type(n),'  isinstance =',isinstance(n,KValue))
print('type(A) =',type(A),'  isValue =',isvalue(A))
print('type(e) =',type(e),'  isValue =',isvalue(e))
print('type(n) =',type(n),'  isValue =',isvalue(n))
print('val(e) =',val(e))
f = sqrt(a+b-x)  #genera eccezione: SISTEMARE
g = sqrt(abs(a+b-x))
h = sin(x+y)
k = cos(x-y)
l = tan(x*y)

p1 = x**y
p2 = x**2
p3 = 3**y
q1 = pow(x,y)
q2 = pow(x,2)
q3 = pow(3,y)  

a1 = 1+x
b1 = 3-2+x-y
c1 = -1*x*y
d1 = x/-y

t1 = x==y
t2 = x<c
#t3 = (t1 and t2)  #ERR: interferisce nella write della t1!!! SISTEMARE
t3 = x==y and x<c

write('coordx(A)=',x)
write('coordy(A)=',y)
write('x+y=',a)
write('x-y=',b)
write('x*y=',c)
write('x/y=',d)
write('x/0=',z)
write('(-x-a*y)/(a*a-4*d-math.sin(2))=',e)
write('sqrt(a+b-x)=',f)  
write('sqrt(abs(a+b-x))=',g)
write('sin(x+y)=',h)
write('cos(x-y)=',k)
write('tan(x*y)=',l)
write('x**y=',p1)
write('x**2=',p2)
write('3**y=',p3)
write('pow(x,y)=',q1)
write('pow(x,2)=',q2)
write('pow(3,y)=',q3)
write('x==y = ',t1)
write('x<y = ',t2)
write('t1 and t2 = ',t3)
