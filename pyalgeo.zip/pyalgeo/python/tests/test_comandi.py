# File: test_comandi.py 
# Date: 23 ago 22 - ..
# Note: test sui comandi da programma e da linea di comando


grid()

#s0 = Segment(INPUT,width=3,state=OPERABLE,msg='segmento spesso e operabile...',name='s0')


O = Point((2,5),name='O',color='brown',state=OPERABLE)
S = Point((2,3),name='S',color='red',state=SENSIBLE)
D = Point((2,1),name='D',color='blue',state=DRAGABLE)

'''
setcolor('orange')
setwidth(3)  #viene risettata sotto
s1 = Segment(INPUT,width=1,msg='segmento sottile con attributi semimpostati...',name='s1')
col1 = s1.getcolor() #
col = getcolor()
P = Point(INPUT,msg='punto blue...',color='blue',state=DRAGABLE)
#t = Segment(Point(2,3),Point(4,5)).config(color='orange',state=DRAGABLE,width=3)
setcolor(col)
s2 = Segment(INPUT,width=2,msg='segmento medio arancione...',name='s2')
w2 = s2.getwidth()
setwidth(3)
setstate(OPERABLE)
s3 = Segment(INPUT,msg='segmento rosso grosso fisso...',color='red',name='s3')
t3 = P.getstate()
#print('-----------> stato attuale=',getstate())
print('-----------> stato di P =',t3)
s1.config(color=getcolor(),width=getwidth(),state=getstate()) #ERR non setta lo stato
s1.setcolor('brown')
s0.config(color=col1,width=w2,state=t3) #orange/2/DRAGABLE
'''


'''
#---- costruttori di base ---- ok 16ago22
# definizione di primitive fisse
P = Point((-2,2)).config(name='P',color='green',state=DRAGABLE)
Q = Point((1,3)).config(name='Q',color='green',state=DRAGABLE)
s = Segment(P,Q,color='orange',name='s',state=DRAGABLE)
c = Circle(Point((1,2)),1.8,color='red',state=DRAGABLE)#.config(name='c',state=const.DRAGABLE,width=1,color='black')
r = Line(Point(2,-1),Point(3,4),color='blue',state=DRAGABLE)
A = Point(3,2,state=DRAGABLE)
B = Point(4,1,state=DRAGABLE)
r2 = Line(A,B,color='orange',state=DRAGABLE)
'''

'''
#---- input circ con centro fisso ----
message('input circonferenza con centro fisso invisibile...')
R = Point(INPUT,state=INVISIBLE)
f = Circle(INPUT,node=R,color='blue',name='F',state=DRAGABLE)

'''
